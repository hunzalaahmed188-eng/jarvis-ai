# JARVIS AI (Android)

A personal AI assistant for Android: voice + text chat, a modular **Skills** system, app hand-offs
(WhatsApp, Browser, Phone, SMS, Calendar, Files), a Daraz Seller Center skill, task history with
confirmations, and encrypted key storage.

Kotlin · Jetpack Compose · MVVM · Coroutines/Flow · Room · WorkManager · min SDK 26 · compile/target SDK 35.

> **Honest status.** This project was authored in a sandbox that had **no Android SDK and no access to
> Google's Maven / Gradle servers**, so it has **never been compiled, run, or unit-tested by its author**.
> Expect a few compile errors or version bumps on the first build. Nothing below is claimed as "working"
> until you have built it and tried it on a device. See *Verification status* at the bottom.

## Build it (pick one)

### A. Cloud build (no local setup) – GitHub Actions
1. Create a GitHub repo and push this folder (`git init && git add . && git commit -m init && git push`).
2. Open **Actions → Android CI → Run workflow** (it also runs on every push).
3. When it finishes, download the **`jarvis-debug-apk`** artifact (`app-debug.apk`). Test reports are in **`unit-test-reports`**.
   If it fails, the log shows the compile error; fix it and push again.

### B. Android Studio
1. Install a current Android Studio (JDK 17+).
2. **File → Open** this folder, let Gradle sync (it uses Gradle 8.9+; if prompted, accept the bundled Gradle or
   run `gradle wrapper --gradle-version 8.9` once to generate `gradlew`).
3. Run on a device/emulator, or **Build → Build APK(s)**.

### C. Command line
`gradle testDebugUnitTest assembleDebug` → `app/build/outputs/apk/debug/app-debug.apk`
(requires JDK 17, Android SDK platform 35, Gradle 8.9).

> Version pins (AGP 8.6.1, Kotlin 2.0.20, Compose BOM 2024.09.03, Room 2.6.1) are a known-compatible set;
> bump them if your toolchain complains. To target a newer SDK, raise `compileSdk`/`targetSdk` in `app/build.gradle.kts`.

## Configuration (no secrets in the repo)
* `jarvis.properties.example` → copy to `jarvis.properties` (git-ignored) to change the *default* endpoint/model/provider name.
* Your **API key is never in source or build files**. Enter it in **Settings → API key**; it is stored with
  `EncryptedSharedPreferences` (Android Keystore). Use any **OpenAI-compatible** `…/chat/completions` HTTPS endpoint.

## Using it
* Type or tap the mic. Commands handled by skills (work without an API key):
  `search …`, `open daraz.pk`, `WhatsApp 0300 1234567 saying I'll be late`, `SMS +923001234567 saying hi`,
  `call 0300 1234567`, `add event dentist`, `open files`, `Daraz seller center`,
  `remember that I prefer short answers`.
* Anything else goes to your AI model (needs an API key).
* Messages, memory saves and other sensitive actions show a **Confirm** dialog first. WhatsApp/SMS only open a
  *draft*; **you** press Send. There is no unattended sending.

## Architecture
```
app/src/main/java/com/jarvis/ai
  JarvisApp.kt            AppContainer (manual DI), skill registration
  core/                   settings model, enums
  data/                   Room entities/DAOs, SecureStore, SettingsStore
  ai/                     OpenAI-compatible client, payload + prompt builders
  skills/                 Skill API (SkillApi.kt), built-in skills, Daraz, registry
  tasks/                  AssistantEngine (routing, confirmation, retry, logs), Notifier, WorkManager worker
  voice/                  SpeechRecognizer + TextToSpeech wrappers, WakeWordService
  ui/                     Compose screens + ViewModels
```

### Adding a skill (developer guide)
1. Implement `Skill` (see `skills/SkillApi.kt` for the contract and `BuiltInSkills.kt` for examples):
   `plan()` decides whether the text is yours and proposes a `PlannedAction` (no side effects);
   `execute()` performs it. Set `sensitive = true` for anything that sends/deletes/spends.
2. Add the instance to `builtInSkills` in `JarvisApp.kt`.
3. It automatically shows up in **Skills** with its permissions and required apps, can be enabled/disabled/removed,
   and its runs appear in **Tasks & logs** with retry and confirmation handled by the engine.

Users can also add **prompt skills** in the app (trigger word + instruction sent to the AI).

## Implemented (written; see verification status)
Chat UI with history (Room) · configurable AI endpoint/model · encrypted API key · English/Urdu/Roman-Urdu
prompting + STT/TTS locales · mic permission rationale · STT/TTS with start/stop · experimental wake-word
foreground service · status indicator · Skills manager (enable/disable/remove/restore/add, permissions, required apps) ·
Connected Apps screen with honest status · WhatsApp/SMS/Phone/Calendar/Files/Browser intent skills · Daraz skill
(open Seller Center, AI listing drafts, read-only orders via Open Platform) · memory (user-approved only, viewable/deletable) ·
task history, statuses, logs, capped retry, reminders via WorkManager · settings (provider, key, language, voice,
speed/pitch, theme, notifications, permissions, privacy, memory) · clear chat / tasks / erase-all.

## Needs extra permissions, accounts or APIs (not automatic)
| Feature | Requirement |
|---|---|
| AI chat | Your own API key for an OpenAI-compatible provider |
| Speech-to-text | `RECORD_AUDIO` + a device speech recognizer (often needs internet; Urdu needs its language pack) |
| Urdu speech output | An installed Urdu TTS voice |
| Wake word | Mic permission, foreground service, notification; must be started with the app visible; OEM battery savers may kill it. Not an on-device keyword spotter. |
| WhatsApp | WhatsApp installed. Only click-to-chat drafts (no official API for sending on a personal account). The WhatsApp **Business Platform** (Cloud API) is a separate server-side integration and is not included. |
| Daraz orders | A Daraz Open Platform app (key + secret) and a seller access token you authorise yourself. Request signing is unit-tested; the live call is **unverified**. |
| Daraz inventory/listing edits | Not automated (manual workflow shown in-app). |
| Contacts by name, reading calendar, searching files, auto-sending SMS | Not implemented (would need extra permissions; deliberately avoided). |

## Known limitations
* Contact names aren't resolved; say the phone number. Number defaults to country code **92** (configurable).
* Scheduled tasks are reminders; commands run only when you tap *Run as command*. WorkManager timing is approximate.
* Room uses destructive migration in this first version.
* Not hardened for release: no R8/signing config, no instrumented/UI tests.

## Verification status
| Item | Status |
|---|---|
| Source written | Yes |
| Compiled | **No** (no SDK/network in authoring environment) |
| Unit tests (`app/src/test`) | Written (payload building/parsing, prompt, phone/URL/WhatsApp parsing, Daraz signing + parsing); **not run** |
| Run on a device | **No** |
| Skill `plan()` logic, UI, voice, service, Room, WorkManager | Not tested |
