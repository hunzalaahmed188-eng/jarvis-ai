package com.jarvis.ai

import com.jarvis.ai.ai.AiException
import com.jarvis.ai.ai.ChatPayload
import com.jarvis.ai.ai.ChatTurn
import com.jarvis.ai.ai.PromptBuilder
import com.jarvis.ai.core.LanguageMode
import com.jarvis.ai.skills.*
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test

class ChatPayloadTest {
    @Test fun buildPutsSystemFirstAndKeepsOrder() {
        val json = JSONObject(ChatPayload.build("m1", "SYS", listOf(ChatTurn("user", "hi"), ChatTurn("assistant", "hello"))))
        assertEquals("m1", json.getString("model"))
        val msgs = json.getJSONArray("messages")
        assertEquals(3, msgs.length())
        assertEquals("system", msgs.getJSONObject(0).getString("role"))
        assertEquals("SYS", msgs.getJSONObject(0).getString("content"))
        assertEquals("hello", msgs.getJSONObject(2).getString("content"))
    }

    @Test fun parseReplyExtractsAndTrimsContent() {
        val body = """{"choices":[{"message":{"role":"assistant","content":"  Hello  "}}]}"""
        assertEquals("Hello", ChatPayload.parseReply(body))
    }

    @Test(expected = AiException::class) fun parseReplyRejectsGarbage() { ChatPayload.parseReply("<html>nope</html>") }

    @Test(expected = AiException::class) fun parseReplyRejectsEmptyContent() {
        ChatPayload.parseReply("""{"choices":[{"message":{"content":"  "}}]}""")
    }

    @Test fun httpErrorsAreHumanReadable() {
        assertTrue(ChatPayload.describeHttpError(401, "").contains("API key"))
        assertTrue(ChatPayload.describeHttpError(429, "").contains("Rate limit"))
        assertTrue(ChatPayload.describeHttpError(500, "").contains("server error"))
        assertTrue(ChatPayload.describeHttpError(400, """{"error":{"message":"bad model"}}""").contains("bad model"))
    }
}

class PromptBuilderTest {
    @Test fun includesLanguageMemoriesAndSkills() {
        val p = PromptBuilder.system(LanguageMode.ROMAN_URDU, listOf("prefers short answers"), listOf("Browser"))
        assertTrue(p.contains("Roman Urdu"))
        assertTrue(p.contains("prefers short answers"))
        assertTrue(p.contains("Browser"))
    }

    @Test fun omitsMemorySectionWhenEmpty() {
        assertFalse(PromptBuilder.system(LanguageMode.ENGLISH, emptyList(), emptyList()).contains("preferences to respect"))
    }

    @Test fun languageModeLookup() {
        assertEquals(LanguageMode.AUTO, LanguageMode.fromName(null))
        assertEquals(LanguageMode.URDU, LanguageMode.fromName("URDU"))
        assertEquals("ur-PK", LanguageMode.URDU.sttTag())
    }
}

class ParsingTest {
    @Test fun phoneNormalisation() {
        assertEquals("923001234567", PhoneNumbers.toInternational("0300-1234567", "92"))
        assertEquals("923001234567", PhoneNumbers.toInternational("+92 300 1234567", "92"))
        assertEquals("923001234567", PhoneNumbers.toInternational("00923001234567", "92"))
        assertNull(PhoneNumbers.toInternational("123", "92"))
    }

    @Test fun findsPhoneAndBody() {
        val input = "WhatsApp 0300 1234567 saying I'll be late"
        val phone = PhoneNumbers.find(input)!!
        assertEquals("0300 1234567", phone)
        assertEquals("I'll be late", MessageParser.bodyAfter(input, phone))
    }

    @Test fun bodyStripsFillerAndQuotes() {
        val input = "sms +923001234567 that \"call me\""
        assertEquals("call me", MessageParser.bodyAfter(input, PhoneNumbers.find(input)!!))
    }

    @Test fun whatsAppLinkEncodesText() {
        assertEquals("https://wa.me/923001234567", WhatsAppLinks.chatUrl("923001234567", null))
        assertEquals("https://wa.me/923001234567?text=Hello%20world%20%26%20more", WhatsAppLinks.chatUrl("923001234567", "Hello world & more"))
    }

    @Test fun urlDetection() {
        assertEquals("https://daraz.pk", UrlDetector.findUrl("open daraz.pk"))
        assertEquals("https://example.com/a", UrlDetector.findUrl("go to https://example.com/a now".substringBefore(" now")))
        assertNull(UrlDetector.findUrl("what is the weather"))
    }

    @Test fun searchQueryAndUrl() {
        assertEquals("weather in Karachi", UrlDetector.searchQuery("search weather in Karachi"))
        assertEquals("https://www.google.com/search?q=weather%20in%20Karachi", UrlDetector.searchUrl("weather in Karachi"))
    }

    @Test fun paramsRoundTrip() {
        val m = mapOf("a" to "1", "text" to "héllo \"quoted\"")
        assertEquals(m, ParamsJson.decode(ParamsJson.encode(m)))
        assertTrue(ParamsJson.decode("not json").isEmpty())
    }
}

class DarazTest {
    @Test fun signatureMatchesReferenceHmac() {
        val params = mapOf(
            "app_key" to "100001", "timestamp" to "1700000000000", "sign_method" to "sha256",
            "access_token" to "tok123", "created_after" to "2026-11-01T00:00:00+05:00",
        )
        // Reference computed independently with Python hmac/hashlib.
        assertEquals("FD51198C549E0F445381B084E677C13D0B71734960AE2A194D9D88A45E596C77", DarazSigner.sign("/orders/get", params, "s3cr3t"))
    }

    @Test fun signIgnoresExistingSignParam() {
        val base = mapOf("a" to "1")
        assertEquals(DarazSigner.sign("/x", base, "k"), DarazSigner.sign("/x", base + ("sign" to "ZZZ"), "k"))
    }

    @Test fun parsesOrdersSummary() {
        val body = """{"code":"0","data":{"count":3,"orders":[
            {"order_id":1,"price":"1500.50","statuses":["pending"]},
            {"order_id":2,"price":"500","statuses":["delivered"]},
            {"order_id":3,"price":"100.00","statuses":["pending"]}]}}"""
        val s = DarazParser.parseOrders(body)
        assertEquals(3, s.count)
        assertEquals(2100.5, s.revenue, 0.001)
        assertEquals(2, s.byStatus["pending"])
        assertEquals(1, s.byStatus["delivered"])
    }

    @Test fun emptyOrdersIsZero() {
        assertEquals(0, DarazParser.parseOrders("""{"code":"0","data":{}}""").count)
    }

    @Test(expected = DarazException::class) fun apiErrorCodeThrows() {
        DarazParser.parseOrders("""{"code":"IllegalAccessToken","message":"bad token"}""")
    }

    @Test fun credentialsCompleteness() {
        assertFalse(DarazCredentials("a", "", "c").complete)
        assertTrue(DarazCredentials("a", "b", "c").complete)
    }
}
