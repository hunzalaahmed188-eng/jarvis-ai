package com.jarvis.ai

import android.app.Application
import androidx.room.Room
import com.jarvis.ai.ai.AiClient
import com.jarvis.ai.data.JarvisDatabase
import com.jarvis.ai.data.SecureStore
import com.jarvis.ai.data.SettingsStore
import com.jarvis.ai.skills.*
import com.jarvis.ai.tasks.AssistantEngine
import com.jarvis.ai.tasks.Notifier
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import java.util.concurrent.TimeUnit

class JarvisApp : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
        container.notifier.ensureChannels()
        container.onAppStart()
    }
}

/** Simple manual dependency container (no DI framework needed at this size). */
class AppContainer(val app: Application) {
    val db: JarvisDatabase = Room.databaseBuilder(app, JarvisDatabase::class.java, "jarvis.db")
        .fallbackToDestructiveMigration()
        .build()
    val secure = SecureStore(app)
    val settings = SettingsStore(app)
    val http: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()
    val aiClient = AiClient(http)
    val notifier = Notifier(app, settings)
    val darazApi = DarazApiClient(http)

    /** Register new built-in skills here. */
    val builtInSkills: List<Skill> = listOf(
        MemorySkill(),
        WhatsAppSkill(),
        DarazSkill(darazApi),
        SmsSkill(),
        PhoneSkill(),
        CalendarSkill(),
        FilesSkill(),
        BrowserSkill(),
    )
    val registry = SkillRegistry(builtInSkills, db.customSkillDao(), db.skillStateDao())
    val engine = AssistantEngine(this)

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    fun onAppStart() {
        scope.launch { if (!settings.value.saveHistory) db.messageDao().clear() }
    }

    /** Wipes conversation, memory, tasks, logs, custom skills, secrets and settings. */
    suspend fun wipeEverything() {
        db.clearAllTables()
        secure.clearAll()
        settings.reset()
    }
}
