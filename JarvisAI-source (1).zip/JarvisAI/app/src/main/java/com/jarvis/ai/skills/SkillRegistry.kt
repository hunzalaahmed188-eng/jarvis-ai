package com.jarvis.ai.skills

import com.jarvis.ai.data.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine

data class SkillInfo(
    val id: String,
    val name: String,
    val description: String,
    val builtIn: Boolean,
    val enabled: Boolean,
    val requiredApps: List<String>,
    val permissions: List<SkillPermission>,
)

/** A user-defined skill: if the message starts with [trigger], the instruction + message go to the AI. */
class PromptSkill(private val e: CustomSkillEntity) : Skill {
    override val id = "custom:${e.id}"
    override val name = e.name
    override val description = e.description
    override val requiredApps = emptyList<String>()
    override val permissions = listOf(SkillPermission("Internet (AI provider)", "Sends your message and this skill's instruction to your configured AI model."))

    override suspend fun plan(input: String, ctx: SkillContext): SkillPlan {
        if (!input.trim().startsWith(e.trigger.trim(), ignoreCase = true)) return SkillPlan.NotHandled
        val rest = input.trim().substring(e.trigger.trim().length).trim()
        return SkillPlan.Act(PlannedAction(id, "run_prompt", mapOf("input" to rest), "Run custom skill \"${e.name}\"", sensitive = false, launchesUi = false))
    }

    override suspend fun execute(action: PlannedAction, ctx: SkillContext): SkillOutcome =
        SkillOutcome(true, ctx.ask(e.instruction + "\n" + ctx.language.promptInstruction, action.params["input"].orEmpty()))
}

class SkillRegistry(
    private val builtIns: List<Skill>,
    private val customDao: CustomSkillDao,
    private val stateDao: SkillStateDao,
) {
    fun observeInfos(): Flow<List<SkillInfo>> =
        combine(customDao.observeAll(), stateDao.observeAll()) { customs, states ->
            val st = states.associateBy { it.skillId }
            val built = builtIns.filter { st[it.id]?.removed != true }.map { it.toInfo(true, st[it.id]?.enabled != false) }
            val cust = customs.map { PromptSkill(it).toInfo(false, st["custom:${it.id}"]?.enabled != false) }
            built + cust
        }

    private fun Skill.toInfo(builtIn: Boolean, enabled: Boolean) =
        SkillInfo(id, name, description, builtIn, enabled, requiredApps, permissions)

    private suspend fun allSkills(): List<Skill> = builtIns + customDao.getAll().map { PromptSkill(it) }

    suspend fun enabledSkills(): List<Skill> {
        val st = stateDao.getAll().associateBy { it.skillId }
        return allSkills().filter { st[it.id]?.removed != true && st[it.id]?.enabled != false }
    }

    suspend fun find(id: String): Skill? = allSkills().firstOrNull { it.id == id }

    suspend fun setEnabled(id: String, enabled: Boolean) {
        val cur = stateDao.get(id)
        stateDao.upsert(SkillStateEntity(id, enabled, cur?.removed ?: false))
    }

    suspend fun remove(info: SkillInfo) {
        if (info.builtIn) stateDao.upsert(SkillStateEntity(info.id, enabled = false, removed = true))
        else {
            customDao.delete(info.id.removePrefix("custom:").toLong())
            stateDao.delete(info.id)
        }
    }

    suspend fun restoreBuiltIns() = builtIns.forEach { stateDao.upsert(SkillStateEntity(it.id, enabled = true, removed = false)) }

    suspend fun addCustom(name: String, description: String, trigger: String, instruction: String) {
        customDao.insert(CustomSkillEntity(name = name.trim(), description = description.trim(), trigger = trigger.trim(), instruction = instruction.trim()))
    }
}
