package com.jarvis.ai.tasks

import android.Manifest
import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.jarvis.ai.MainActivity
import com.jarvis.ai.R
import com.jarvis.ai.data.SettingsStore

class Notifier(private val context: Context, private val settings: SettingsStore) {
    companion object {
        const val CH_TASKS = "jarvis_tasks"
        const val CH_SERVICE = "jarvis_service"
        const val SERVICE_NOTIFICATION_ID = 1001
    }

    fun ensureChannels() {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = context.getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel(CH_TASKS, "Tasks & confirmations", NotificationManager.IMPORTANCE_DEFAULT))
            nm.createNotificationChannel(NotificationChannel(CH_SERVICE, "Wake-word listening", NotificationManager.IMPORTANCE_LOW))
        }
    }

    private fun openAppIntent(): PendingIntent = PendingIntent.getActivity(
        context, 0, Intent(context, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
    )

    @SuppressLint("MissingPermission")
    fun notifyTask(title: String, text: String) {
        if (!settings.value.notificationsEnabled) return
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return
        val n = NotificationCompat.Builder(context, CH_TASKS)
            .setSmallIcon(R.drawable.ic_stat_jarvis)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setContentIntent(openAppIntent())
            .setAutoCancel(true)
            .build()
        NotificationManagerCompat.from(context).notify((System.currentTimeMillis() % 100000).toInt() + 2000, n)
    }

    fun serviceNotification(stopIntent: PendingIntent): Notification =
        NotificationCompat.Builder(context, CH_SERVICE)
            .setSmallIcon(R.drawable.ic_stat_jarvis)
            .setContentTitle("JARVIS is listening for the wake word")
            .setContentText("Tap Stop to turn this off.")
            .setContentIntent(openAppIntent())
            .setOngoing(true)
            .addAction(0, "Stop", stopIntent)
            .build()
}
