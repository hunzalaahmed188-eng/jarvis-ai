package com.jarvis.ai.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface MessageDao {
    @Query("SELECT * FROM messages ORDER BY id ASC")
    fun observeAll(): Flow<List<MessageEntity>>

    @Query("SELECT * FROM messages ORDER BY id DESC LIMIT :limit")
    suspend fun recent(limit: Int): List<MessageEntity>

    @Insert
    suspend fun insert(m: MessageEntity): Long

    @Query("DELETE FROM messages")
    suspend fun clear()
}

@Dao
interface MemoryDao {
    @Query("SELECT * FROM memories ORDER BY id ASC")
    fun observeAll(): Flow<List<MemoryEntity>>

    @Query("SELECT * FROM memories ORDER BY id ASC")
    suspend fun getAll(): List<MemoryEntity>

    @Insert
    suspend fun insert(m: MemoryEntity): Long

    @Query("DELETE FROM memories WHERE id = :id")
    suspend fun delete(id: Long)

    @Query("DELETE FROM memories")
    suspend fun clear()
}

@Dao
interface TaskDao {
    @Query("SELECT * FROM tasks ORDER BY id DESC")
    fun observeAll(): Flow<List<TaskEntity>>

    @Query("SELECT * FROM tasks WHERE id = :id")
    suspend fun get(id: Long): TaskEntity?

    @Insert
    suspend fun insert(t: TaskEntity): Long

    @Update
    suspend fun update(t: TaskEntity)

    @Query("DELETE FROM tasks WHERE id = :id")
    suspend fun delete(id: Long)

    @Query("DELETE FROM tasks")
    suspend fun clear()
}

@Dao
interface LogDao {
    @Query("SELECT * FROM action_logs ORDER BY id DESC LIMIT 200")
    fun observeRecent(): Flow<List<ActionLogEntity>>

    @Insert
    suspend fun insert(l: ActionLogEntity): Long

    @Query("DELETE FROM action_logs")
    suspend fun clear()
}

@Dao
interface SkillStateDao {
    @Query("SELECT * FROM skill_state")
    fun observeAll(): Flow<List<SkillStateEntity>>

    @Query("SELECT * FROM skill_state")
    suspend fun getAll(): List<SkillStateEntity>

    @Query("SELECT * FROM skill_state WHERE skillId = :id")
    suspend fun get(id: String): SkillStateEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(s: SkillStateEntity)

    @Query("DELETE FROM skill_state WHERE skillId = :id")
    suspend fun delete(id: String)

    @Query("DELETE FROM skill_state")
    suspend fun clear()
}

@Dao
interface CustomSkillDao {
    @Query("SELECT * FROM custom_skills ORDER BY id ASC")
    fun observeAll(): Flow<List<CustomSkillEntity>>

    @Query("SELECT * FROM custom_skills ORDER BY id ASC")
    suspend fun getAll(): List<CustomSkillEntity>

    @Insert
    suspend fun insert(s: CustomSkillEntity): Long

    @Query("DELETE FROM custom_skills WHERE id = :id")
    suspend fun delete(id: Long)

    @Query("DELETE FROM custom_skills")
    suspend fun clear()
}

@Database(
    entities = [
        MessageEntity::class, MemoryEntity::class, TaskEntity::class,
        ActionLogEntity::class, SkillStateEntity::class, CustomSkillEntity::class,
    ],
    version = 1,
    exportSchema = false,
)
abstract class JarvisDatabase : RoomDatabase() {
    abstract fun messageDao(): MessageDao
    abstract fun memoryDao(): MemoryDao
    abstract fun taskDao(): TaskDao
    abstract fun logDao(): LogDao
    abstract fun skillStateDao(): SkillStateDao
    abstract fun customSkillDao(): CustomSkillDao
}
