package com.jarvis.ai.ui

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.jarvis.ai.core.AssistantStatus
import com.jarvis.ai.ui.theme.JarvisAmber

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(vm: MainViewModel, nav: NavController) {
    val messages by vm.messages.collectAsStateWithLifecycle()
    val status by vm.status.collectAsStateWithLifecycle()
    val partial by vm.partial.collectAsStateWithLifecycle()
    val error by vm.error.collectAsStateWithLifecycle()
    var input by remember { mutableStateOf("") }
    val listState = rememberLazyListState()
    val context = LocalContext.current
    var showRationale by remember { mutableStateOf(false) }

    val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) vm.startListening()
        else vm.setError("Microphone permission denied. You can still type, or enable it in Settings → Permissions.")
    }
    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }

    LaunchedEffect(Unit) {
        if (android.os.Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
    }
    LaunchedEffect(messages.size) { if (messages.isNotEmpty()) listState.animateScrollToItem(messages.lastIndex) }

    fun onMic() {
        when {
            status == AssistantStatus.LISTENING -> vm.stopListening()
            ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED -> vm.startListening()
            else -> showRationale = true
        }
    }

    if (showRationale) {
        AlertDialog(
            onDismissRequest = { showRationale = false },
            title = { Text("Microphone access") },
            text = { Text("JARVIS needs the microphone only while you tap the mic button, to turn your speech into text. Audio is handled by Android's speech recognizer; JARVIS doesn't record or store it.") },
            confirmButton = { TextButton(onClick = { showRationale = false; micLauncher.launch(Manifest.permission.RECORD_AUDIO) }) { Text("Continue") } },
            dismissButton = { TextButton(onClick = { showRationale = false }) { Text("Not now") } },
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("JARVIS", style = MaterialTheme.typography.titleLarge)
                        StatusLine(status)
                    }
                },
                actions = {
                    IconButton(onClick = { nav.navigate("apps") }) { Icon(Icons.Default.Apps, "Connected apps") }
                    IconButton(onClick = { nav.navigate("skills") }) { Icon(Icons.Default.Extension, "Skills") }
                    IconButton(onClick = { nav.navigate("tasks") }) { Icon(Icons.Default.History, "Tasks") }
                    IconButton(onClick = { nav.navigate("settings") }) { Icon(Icons.Default.Settings, "Settings") }
                },
            )
        },
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().imePadding()) {
            if (messages.isEmpty()) {
                Column(Modifier.weight(1f).padding(24.dp), verticalArrangement = Arrangement.Center) {
                    Text("At your service.", style = MaterialTheme.typography.headlineSmall, color = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.height(8.dp))
                    Text("Type or tap the mic. Try:\n• search weather in Karachi\n• WhatsApp 0300 1234567 saying I'll be late\n• Daraz seller center\n• remember that I prefer short answers\n\nTo chat with the AI, add your API key in Settings.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            } else {
                LazyColumn(Modifier.weight(1f).padding(horizontal = 12.dp), state = listState, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(messages, key = { it.id }) { m -> Bubble(m.role, m.content) }
                }
            }
            error?.let {
                Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp))
            }
            if (partial.isNotBlank()) {
                Text("“$partial”", color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp))
            }
            Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = input, onValueChange = { input = it },
                    modifier = Modifier.weight(1f), placeholder = { Text("Message JARVIS…") },
                    maxLines = 4, shape = RoundedCornerShape(24.dp),
                )
                Spacer(Modifier.width(6.dp))
                if (input.isNotBlank()) {
                    FilledIconButton(onClick = { vm.send(input); input = "" }) { Icon(Icons.AutoMirrored.Filled.Send, "Send") }
                } else {
                    val listening = status == AssistantStatus.LISTENING
                    FilledIconButton(onClick = ::onMic, colors = IconButtonDefaults.filledIconButtonColors(
                        containerColor = if (listening) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary)) {
                        Icon(if (listening) Icons.Default.Stop else Icons.Default.Mic, if (listening) "Stop listening" else "Start listening")
                    }
                }
                if (status == AssistantStatus.SPEAKING) {
                    IconButton(onClick = vm::stopSpeaking) { Icon(Icons.Default.VolumeOff, "Stop speaking") }
                }
            }
        }
    }
}

@Composable
private fun StatusLine(status: AssistantStatus) {
    val color = when (status) {
        AssistantStatus.IDLE -> Color(0xFF4CAF50)
        AssistantStatus.LISTENING -> MaterialTheme.colorScheme.primary
        AssistantStatus.THINKING -> JarvisAmber
        AssistantStatus.SPEAKING -> Color(0xFF7C4DFF)
        AssistantStatus.ERROR -> MaterialTheme.colorScheme.error
    }
    val pulse by rememberInfiniteTransition(label = "pulse").animateFloat(
        initialValue = 0.35f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(700), RepeatMode.Reverse), label = "alpha",
    )
    val animate = status == AssistantStatus.LISTENING || status == AssistantStatus.THINKING
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(9.dp).alpha(if (animate) pulse else 1f).background(color, CircleShape))
        Spacer(Modifier.width(6.dp))
        Text(status.label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun Bubble(role: String, text: String) {
    val isUser = role == "user"
    val bg = when (role) {
        "user" -> MaterialTheme.colorScheme.primaryContainer
        "error" -> MaterialTheme.colorScheme.errorContainer
        else -> MaterialTheme.colorScheme.surfaceVariant
    }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start) {
        Box(Modifier.widthIn(max = 320.dp).clip(RoundedCornerShape(16.dp)).background(bg).padding(12.dp)) {
            Text(text)
        }
    }
}
