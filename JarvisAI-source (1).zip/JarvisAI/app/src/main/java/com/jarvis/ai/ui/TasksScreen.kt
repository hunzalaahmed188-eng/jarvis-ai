package com.jarvis.ai.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.jarvis.ai.core.TaskStatus
import com.jarvis.ai.data.TaskEntity

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TasksScreen(vm: MainViewModel, nav: NavController) {
    val tasks by vm.tasks.collectAsStateWithLifecycle()
    val logs by vm.logs.collectAsStateWithLifecycle()
    var scheduling by remember { mutableStateOf(false) }

    ScreenScaffold("Tasks & logs", nav,
        actions = { TextButton(onClick = { vm.clearTasksAndLogs() }) { Text("Clear") } },
        floating = { ExtendedFloatingActionButton(onClick = { scheduling = true }, icon = { Icon(Icons.Default.Schedule, null) }, text = { Text("Schedule") }) },
    ) { pad ->
        LazyColumn(Modifier.padding(pad).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            item { SectionTitle("Tasks") }
            if (tasks.isEmpty()) item { Text("No tasks yet. Actions you ask JARVIS to perform appear here.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
            items(tasks, key = { it.id }) { t -> TaskCard(t, vm) }
            item { SectionTitle("Action log") }
            if (logs.isEmpty()) item { Text("Nothing logged.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
            items(logs, key = { "log-${it.id}" }) { l ->
                Text("${formatTime(l.createdAt)}  ${l.message}", style = MaterialTheme.typography.bodySmall)
            }
            item { Spacer(Modifier.height(88.dp)) }
        }
    }
    if (scheduling) ScheduleDialog(onDismiss = { scheduling = false }, onSchedule = { text, min -> vm.schedule(text, min); scheduling = false })
}

@Composable
private fun TaskCard(t: TaskEntity, vm: MainViewModel) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp)) {
            Text(t.title, style = MaterialTheme.typography.bodyLarge)
            Text("${t.status.replace('_', ' ')} • ${formatTime(t.createdAt)} • attempts ${t.attempts}" +
                (t.scheduledAt?.let { " • due ${formatTime(it)}" } ?: ""), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
            t.lastError?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error, maxLines = 4) }
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                when (t.status) {
                    TaskStatus.FAILED -> { if (t.attempts < TaskStatus.MAX_ATTEMPTS) TextButton(onClick = { vm.retry(t.id) }) { Text("Retry") } }
                    TaskStatus.PENDING_CONFIRMATION, TaskStatus.SCHEDULED -> TextButton(onClick = { vm.cancel(t.id) }) { Text("Cancel") }
                    TaskStatus.DUE -> {
                        TextButton(onClick = { vm.runDueCommand(t.id, t.title) }) { Text("Run as command") }
                        TextButton(onClick = { vm.markDone(t.id) }) { Text("Done") }
                    }
                    else -> {}
                }
                TextButton(onClick = { vm.deleteTask(t.id) }) { Text("Delete") }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ScheduleDialog(onDismiss: () -> Unit, onSchedule: (String, Long) -> Unit) {
    var text by remember { mutableStateOf("") }
    var minutes by remember { mutableStateOf(15L) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Schedule a reminder") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(text, { text = it }, label = { Text("Reminder or command") })
                Text("When it's due you get a notification. Commands only run when you tap “Run as command”, and sensitive ones still ask for confirmation. Android may delay it slightly to save battery.", style = MaterialTheme.typography.bodySmall)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(5L to "5 min", 15L to "15 min", 60L to "1 h", 240L to "4 h").forEach { (m, label) ->
                        FilterChip(selected = minutes == m, onClick = { minutes = m }, label = { Text(label) })
                    }
                }
            }
        },
        confirmButton = { TextButton(enabled = text.isNotBlank(), onClick = { onSchedule(text.trim(), minutes) }) { Text("Schedule") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}
