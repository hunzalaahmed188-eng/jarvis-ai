package com.jarvis.ai.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.jarvis.ai.skills.SkillInfo

@Composable
fun SkillsScreen(nav: NavController, vm: SkillsViewModel = viewModel()) {
    val skills by vm.skills.collectAsStateWithLifecycle()
    var adding by remember { mutableStateOf(false) }
    var removing by remember { mutableStateOf<SkillInfo?>(null) }

    ScreenScaffold("Skills", nav,
        actions = { TextButton(onClick = vm::restore) { Text("Restore built-ins") } },
        floating = { FloatingActionButton(onClick = { adding = true }) { Icon(Icons.Default.Add, "Add skill") } },
    ) { pad ->
        LazyColumn(Modifier.padding(pad).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                Text("Skills turn your commands into actions. Built-in skills are written in Kotlin (see SkillApi.kt for the developer interface). You can also add prompt skills here.",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            items(skills, key = { it.id }) { s -> SkillCard(s, vm, onRemove = { removing = s }) }
            item { Spacer(Modifier.height(80.dp)) }
        }
    }

    removing?.let { s ->
        AlertDialog(
            onDismissRequest = { removing = null },
            title = { Text("Remove “${s.name}”?") },
            text = { Text(if (s.builtIn) "You can bring built-in skills back with “Restore built-ins”." else "This deletes the custom skill.") },
            confirmButton = { TextButton(onClick = { vm.remove(s); removing = null }) { Text("Remove") } },
            dismissButton = { TextButton(onClick = { removing = null }) { Text("Cancel") } },
        )
    }
    if (adding) AddSkillDialog(onDismiss = { adding = false }, onAdd = { n, d, t, i -> vm.add(n, d, t, i); adding = false })
}

@Composable
private fun SkillCard(s: SkillInfo, vm: SkillsViewModel, onRemove: () -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(s.name, style = MaterialTheme.typography.titleMedium)
                    Text(if (s.builtIn) "Built-in" else "Custom", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                }
                Switch(checked = s.enabled, onCheckedChange = { vm.setEnabled(s.id, it) })
            }
            Text(s.description, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(top = 6.dp))
            Text("Requires: " + (s.requiredApps.joinToString().ifBlank { "no other apps" }), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 4.dp))
            Row {
                TextButton(onClick = { expanded = !expanded }) { Text(if (expanded) "Hide permissions" else "View permissions") }
                Spacer(Modifier.weight(1f))
                IconButton(onClick = onRemove) { Icon(Icons.Default.Delete, "Remove ${s.name}") }
            }
            if (expanded) s.permissions.forEach {
                Text("• ${it.name}: ${it.reason}", style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(bottom = 4.dp))
            }
        }
    }
}

@Composable
private fun AddSkillDialog(onDismiss: () -> Unit, onAdd: (String, String, String, String) -> Unit) {
    var name by remember { mutableStateOf("") }
    var desc by remember { mutableStateOf("") }
    var trigger by remember { mutableStateOf("") }
    var instr by remember { mutableStateOf("") }
    val valid = name.isNotBlank() && trigger.isNotBlank() && instr.isNotBlank()
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add prompt skill") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("When a message starts with the trigger word, JARVIS sends the rest of the message plus your instruction to the AI.", style = MaterialTheme.typography.bodySmall)
                OutlinedTextField(name, { name = it }, label = { Text("Name") }, singleLine = true)
                OutlinedTextField(desc, { desc = it }, label = { Text("Description") })
                OutlinedTextField(trigger, { trigger = it }, label = { Text("Trigger (e.g. “translate”)") }, singleLine = true)
                OutlinedTextField(instr, { instr = it }, label = { Text("Instruction for the AI") }, minLines = 3)
            }
        },
        confirmButton = { TextButton(enabled = valid, onClick = { onAdd(name, desc.ifBlank { "Custom prompt skill" }, trigger, instr) }) { Text("Add") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

@Composable
fun AppsScreen(nav: NavController, vm: AppsViewModel = viewModel()) {
    val items by vm.items.collectAsStateWithLifecycle()
    val testing by vm.testing.collectAsStateWithLifecycle()
    val creds = remember(items) { vm.darazCreds() }
    var appKey by remember(creds) { mutableStateOf(creds.appKey) }
    var secret by remember(creds) { mutableStateOf(creds.appSecret) }
    var token by remember(creds) { mutableStateOf(creds.accessToken) }

    ScreenScaffold("Connected Apps", nav, actions = { TextButton(onClick = vm::refresh) { Text("Refresh") } }) { pad ->
        LazyColumn(Modifier.padding(pad).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                Text("Status is checked from this device. “Available” means Android can open that app for you; it is not a login. Only “Verified working” means a real API call succeeded.",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            items(items, key = { it.id }) { a ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp)) {
                        Text(a.name, style = MaterialTheme.typography.titleMedium)
                        Text(a.status.label, style = MaterialTheme.typography.labelLarge,
                            color = when (a.status) {
                                ConnStatus.VERIFIED, ConnStatus.AVAILABLE -> MaterialTheme.colorScheme.primary
                                ConnStatus.ERROR -> MaterialTheme.colorScheme.error
                                else -> MaterialTheme.colorScheme.secondary
                            })
                        Text(a.detail, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 4.dp))
                        if (a.id == "daraz") {
                            Spacer(Modifier.height(8.dp))
                            Text("Daraz Open Platform credentials (stored encrypted on-device). Requires a registered Open Platform app and seller authorisation; JARVIS cannot create these for you.", style = MaterialTheme.typography.bodySmall)
                            OutlinedTextField(appKey, { appKey = it }, label = { Text("App key") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                            OutlinedTextField(secret, { secret = it }, label = { Text("App secret") }, singleLine = true, visualTransformation = PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password), modifier = Modifier.fillMaxWidth())
                            OutlinedTextField(token, { token = it }, label = { Text("Access token") }, singleLine = true, visualTransformation = PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password), modifier = Modifier.fillMaxWidth())
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 6.dp)) {
                                Button(onClick = { vm.saveDaraz(appKey, secret, token) }) { Text("Save") }
                                OutlinedButton(enabled = !testing && creds.complete, onClick = vm::testDaraz) { Text(if (testing) "Testing…" else "Test connection") }
                                TextButton(onClick = vm::clearDaraz) { Text("Clear") }
                            }
                        }
                    }
                }
            }
            item { Spacer(Modifier.height(24.dp)) }
        }
    }
}
