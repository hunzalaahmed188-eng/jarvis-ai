package com.jarvis.ai.core

import java.util.Locale

/** Conversation language the user prefers. */
enum class LanguageMode(
    val label: String,
    private val stt: String?,
    private val tts: String?,
    val promptInstruction: String,
) {
    AUTO("Auto-detect", null, null, "Reply in the same language and script the user used."),
    ENGLISH("English", "en-US", "en-US", "Always reply in English."),
    URDU("اردو (Urdu)", "ur-PK", "ur-PK", "Always reply in Urdu, written in Urdu script."),
    ROMAN_URDU(
        "Roman Urdu", "ur-PK", "en-IN",
        "Always reply in Roman Urdu: Urdu written in the Latin alphabet, as people type it in Pakistan.",
    );

    fun sttTag(): String = stt ?: Locale.getDefault().toLanguageTag()
    fun ttsTag(): String = tts ?: Locale.getDefault().toLanguageTag()

    companion object {
        fun fromName(name: String?): LanguageMode = entries.firstOrNull { it.name == name } ?: AUTO
    }
}

enum class ThemeMode {
    SYSTEM, DARK, LIGHT;

    companion object {
        fun fromName(name: String?): ThemeMode = entries.firstOrNull { it.name == name } ?: DARK
    }
}

enum class AssistantStatus(val label: String) {
    IDLE("Standing by"),
    LISTENING("Listening…"),
    THINKING("Thinking…"),
    SPEAKING("Speaking…"),
    ERROR("Attention needed"),
}

object TaskStatus {
    const val PENDING_CONFIRMATION = "PENDING_CONFIRMATION"
    const val SCHEDULED = "SCHEDULED"
    const val DUE = "DUE"
    const val RUNNING = "RUNNING"
    const val SUCCESS = "SUCCESS"
    const val FAILED = "FAILED"
    const val CANCELLED = "CANCELLED"
    const val MAX_ATTEMPTS = 3
}

/** Non-secret user settings. Secrets (API keys) live in [com.jarvis.ai.data.SecureStore]. */
data class AppSettings(
    val providerName: String = com.jarvis.ai.BuildConfig.DEFAULT_PROVIDER_NAME,
    val endpoint: String = com.jarvis.ai.BuildConfig.DEFAULT_API_ENDPOINT,
    val model: String = com.jarvis.ai.BuildConfig.DEFAULT_MODEL,
    val language: LanguageMode = LanguageMode.AUTO,
    val speakReplies: Boolean = true,
    val speechRate: Float = 1.0f,
    val speechPitch: Float = 1.0f,
    val theme: ThemeMode = ThemeMode.DARK,
    val wakeWordEnabled: Boolean = false,
    val wakeWord: String = "jarvis",
    val notificationsEnabled: Boolean = true,
    val saveHistory: Boolean = true,
    val memoryEnabled: Boolean = true,
    val defaultCountryCode: String = "92",
)
