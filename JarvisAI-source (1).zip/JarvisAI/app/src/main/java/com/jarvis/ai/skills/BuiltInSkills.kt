package com.jarvis.ai.skills

import android.app.DownloadManager
import android.content.Intent
import android.net.Uri
import android.provider.CalendarContract
import com.jarvis.ai.data.MemoryEntity

internal fun act(
    skill: String, action: String, params: Map<String, String>, summary: String,
    sensitive: Boolean, launchesUi: Boolean, reply: String? = null,
) = SkillPlan.Act(PlannedAction(skill, action, params, summary, sensitive, launchesUi), reply)

internal fun String.has(vararg words: String) = words.any { contains(it, ignoreCase = true) }

/** "remember that I prefer short answers" -> asks confirmation, then stores it. */
class MemorySkill : Skill {
    override val id = "memory"
    override val name = "Memory"
    override val description = "Saves preferences you explicitly ask it to remember (after you confirm)."
    override val requiredApps = emptyList<String>()
    override val permissions = listOf(SkillPermission("None", "Stored only on this device; view or delete in Settings → Memory."))
    private val prefix = Regex("^(?:please\\s+)?(?:remember(?:\\s+that)?|yaad\\s+rakho(?:\\s+(?:ke|k))?|yaad\\s+rakhna)\\s+", RegexOption.IGNORE_CASE)

    override suspend fun plan(input: String, ctx: SkillContext): SkillPlan {
        val m = prefix.find(input.trim()) ?: return SkillPlan.NotHandled
        val text = input.trim().substring(m.range.last + 1).trim()
        if (text.isEmpty()) return SkillPlan.Reply("What should I remember?")
        return act(id, "save", mapOf("text" to text), "Save to memory: \"$text\"", sensitive = true, launchesUi = false)
    }

    override suspend fun execute(action: PlannedAction, ctx: SkillContext): SkillOutcome {
        val text = action.params["text"].orEmpty()
        if (text.isBlank()) return SkillOutcome(false, "Nothing to save.")
        ctx.memory.insert(MemoryEntity(text = text))
        return SkillOutcome(true, "Saved to memory: \"$text\"")
    }
}

class WhatsAppSkill : Skill {
    override val id = "whatsapp"
    override val name = "WhatsApp"
    override val description = "Drafts a message and opens the chat in WhatsApp for you to review. You press Send yourself."
    override val requiredApps = listOf("WhatsApp or WhatsApp Business")
    override val permissions = listOf(
        SkillPermission("None (uses wa.me links)", "Uses WhatsApp's official click-to-chat link. JARVIS never reads your chats and cannot send for you."),
    )

    override suspend fun plan(input: String, ctx: SkillContext): SkillPlan {
        if (!input.has("whatsapp")) return SkillPlan.NotHandled
        val phone = PhoneNumbers.find(input)
        val number = phone?.let { PhoneNumbers.toInternational(it, ctx.defaultCountryCode) }
        if (number == null) {
            return if (input.has("open")) {
                act(id, "open_app", emptyMap(), "Open WhatsApp", sensitive = false, launchesUi = true)
            } else {
                SkillPlan.Reply("Which phone number should I message on WhatsApp? Say it like: \"WhatsApp 0300 1234567 saying I'll be late\". (Contact-name lookup is not implemented, to avoid needing access to your contacts.)")
            }
        }
        val body = MessageParser.bodyAfter(input, phone)
        val summary = if (body.isBlank()) "Open WhatsApp chat with +$number" else "Open WhatsApp chat with +$number with draft: \"$body\""
        return act(id, "draft", mapOf("number" to number, "text" to body), summary, sensitive = true, launchesUi = true,
            reply = "I've prepared a WhatsApp draft. After you confirm it opens in WhatsApp, review it and press Send yourself.")
    }

    override suspend fun execute(action: PlannedAction, ctx: SkillContext): SkillOutcome {
        val pm = ctx.appContext.packageManager
        val pkg = listOf("com.whatsapp", "com.whatsapp.w4b").firstOrNull { p ->
            runCatching { pm.getPackageInfo(p, 0) }.isSuccess
        } ?: return SkillOutcome(false, "WhatsApp is not installed on this device.")
        if (action.actionId == "open_app") {
            val launch = pm.getLaunchIntentForPackage(pkg) ?: return SkillOutcome(false, "Couldn't open WhatsApp.")
            return IntentLauncher.launch(ctx.appContext, launch, "Opened WhatsApp.")
        }
        val url = WhatsAppLinks.chatUrl(action.params["number"].orEmpty(), action.params["text"])
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).setPackage(pkg)
        return IntentLauncher.launch(ctx.appContext, intent, "Opened WhatsApp with your draft. Review it and press Send.")
    }
}

class SmsSkill : Skill {
    override val id = "sms"
    override val name = "SMS"
    override val description = "Prepares a text message in your SMS app. You press Send."
    override val requiredApps = listOf("Any SMS/messaging app")
    override val permissions = listOf(SkillPermission("None (no SEND_SMS)", "Opens your messaging app with the draft; JARVIS cannot send SMS by itself."))

    override suspend fun plan(input: String, ctx: SkillContext): SkillPlan {
        val smsWord = Regex("\\bsms\\b", RegexOption.IGNORE_CASE).containsMatchIn(input)
        val textTo = Regex("\\btext\\s+(?:message\\s+)?(?:to\\s+)?\\+?\\d", RegexOption.IGNORE_CASE).containsMatchIn(input)
        if (!smsWord && !textTo) return SkillPlan.NotHandled
        val phone = PhoneNumbers.find(input) ?: return SkillPlan.Reply("Which number should I text? Say: \"SMS 0300 1234567 saying hello\".")
        val number = PhoneNumbers.toInternational(phone, ctx.defaultCountryCode) ?: return SkillPlan.Reply("That doesn't look like a valid phone number.")
        val body = MessageParser.bodyAfter(input, phone)
        return act(id, "draft", mapOf("number" to "+$number", "text" to body), "Open SMS to +$number" + if (body.isBlank()) "" else " with draft: \"$body\"",
            sensitive = true, launchesUi = true, reply = "I've prepared an SMS draft. You'll press Send in your messaging app.")
    }

    override suspend fun execute(action: PlannedAction, ctx: SkillContext): SkillOutcome {
        val intent = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:${action.params["number"].orEmpty()}"))
            .putExtra("sms_body", action.params["text"].orEmpty())
        return IntentLauncher.launch(ctx.appContext, intent, "Opened your messaging app with the draft.")
    }
}

class PhoneSkill : Skill {
    override val id = "phone"
    override val name = "Phone"
    override val description = "Opens the dialer with a number filled in. You press Call."
    override val requiredApps = listOf("Phone / dialer app")
    override val permissions = listOf(SkillPermission("None (no CALL_PHONE)", "Uses the dialer screen, so the call only starts when you press Call."))

    override suspend fun plan(input: String, ctx: SkillContext): SkillPlan {
        val verb = Regex("\\b(call|dial|ring)\\b", RegexOption.IGNORE_CASE).containsMatchIn(input)
        if (!verb) return SkillPlan.NotHandled
        val startsWithVerb = Regex("^(?:please\\s+)?(?:call|dial|ring)\\b", RegexOption.IGNORE_CASE).containsMatchIn(input.trim())
        val phone = PhoneNumbers.find(input)
            ?: return if (startsWithVerb) SkillPlan.Reply("Which number should I dial? (Contact-name lookup isn't implemented.)") else SkillPlan.NotHandled
        val number = PhoneNumbers.toInternational(phone, ctx.defaultCountryCode) ?: return SkillPlan.Reply("That doesn't look like a valid phone number.")
        return act(id, "dial", mapOf("number" to "+$number"), "Open dialer for +$number", sensitive = false, launchesUi = true)
    }

    override suspend fun execute(action: PlannedAction, ctx: SkillContext): SkillOutcome {
        val intent = Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", action.params["number"].orEmpty(), null))
        return IntentLauncher.launch(ctx.appContext, intent, "Opened the dialer. Press Call to dial.")
    }
}

class CalendarSkill : Skill {
    override val id = "calendar"
    override val name = "Calendar"
    override val description = "Opens a new-event screen in your calendar with the title filled in. You choose time and press Save."
    override val requiredApps = listOf("Any calendar app")
    override val permissions = listOf(SkillPermission("None (no calendar access)", "Uses the calendar app's own new-event screen; JARVIS cannot read your calendar."))
    private val verbs = Regex("^(?:please\\s+)?(?:add|create|set|schedule|new)\\s+(?:an?\\s+)?(?:calendar\\s+)?(?:event|meeting|appointment|reminder)?\\s*(?:called|named|for|about|:)?\\s*", RegexOption.IGNORE_CASE)

    override suspend fun plan(input: String, ctx: SkillContext): SkillPlan {
        val t = input.trim()
        val hit = t.has("calendar") || Regex("^(?:please\\s+)?(?:add|create|schedule|set)\\s+(?:an?\\s+)?(?:event|meeting|appointment)", RegexOption.IGNORE_CASE).containsMatchIn(t)
        if (!hit) return SkillPlan.NotHandled
        val title = verbs.replace(t, "").replace(Regex("\\b(?:in|to|on)\\s+(?:my\\s+)?calendar\\b", RegexOption.IGNORE_CASE), "").trim().ifBlank { "New event" }
        return act(id, "new_event", mapOf("title" to title), "Open calendar to add: \"$title\"", sensitive = false, launchesUi = true)
    }

    override suspend fun execute(action: PlannedAction, ctx: SkillContext): SkillOutcome {
        val intent = Intent(Intent.ACTION_INSERT).setData(CalendarContract.Events.CONTENT_URI)
            .putExtra(CalendarContract.Events.TITLE, action.params["title"].orEmpty())
        return IntentLauncher.launch(ctx.appContext, intent, "Opened your calendar. Pick the time and save.")
    }
}

class FilesSkill : Skill {
    override val id = "files"
    override val name = "Files"
    override val description = "Opens Android's Downloads / Files app. (It cannot read or search files.)"
    override val requiredApps = listOf("System Files / Downloads app")
    override val permissions = listOf(SkillPermission("None", "Only opens the system Files app; no storage access."))

    override suspend fun plan(input: String, ctx: SkillContext): SkillPlan =
        if (input.has("open files", "my files", "file manager", "open downloads", "show downloads"))
            act(id, "open", emptyMap(), "Open the Files / Downloads app", sensitive = false, launchesUi = true)
        else SkillPlan.NotHandled

    override suspend fun execute(action: PlannedAction, ctx: SkillContext): SkillOutcome =
        IntentLauncher.launch(ctx.appContext, Intent(DownloadManager.ACTION_VIEW_DOWNLOADS), "Opened Files.")
}

class BrowserSkill : Skill {
    override val id = "browser"
    override val name = "Browser"
    override val description = "Opens websites and web searches in your default browser."
    override val requiredApps = listOf("Any web browser")
    override val permissions = listOf(SkillPermission("None", "Opens links in your browser; nothing is read back."))

    override suspend fun plan(input: String, ctx: SkillContext): SkillPlan {
        val t = input.trim()
        UrlDetector.findUrl(t)?.let {
            return act(id, "open_url", mapOf("url" to it), "Open $it", sensitive = false, launchesUi = true)
        }
        if (Regex("^(?:please\\s+)?(?:search|google|browse|look\\s+up|find)\\b", RegexOption.IGNORE_CASE).containsMatchIn(t)) {
            val q = UrlDetector.searchQuery(t)
            if (q.isBlank()) return SkillPlan.Reply("What should I search for?")
            return act(id, "open_url", mapOf("url" to UrlDetector.searchUrl(q)), "Search the web for \"$q\"", sensitive = false, launchesUi = true)
        }
        return SkillPlan.NotHandled
    }

    override suspend fun execute(action: PlannedAction, ctx: SkillContext): SkillOutcome {
        val url = action.params["url"].orEmpty()
        if (!url.startsWith("https://") && !url.startsWith("http://")) return SkillOutcome(false, "Invalid URL.")
        return IntentLauncher.launch(ctx.appContext, Intent(Intent.ACTION_VIEW, Uri.parse(url)), "Opened in your browser.")
    }
}
