package com.jarvis.ai.ui

import android.app.Application
import android.content.pm.PackageManager
import android.content.Intent
import android.net.Uri
import android.provider.CalendarContract
import android.app.DownloadManager
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.jarvis.ai.JarvisApp
import com.jarvis.ai.core.*
import com.jarvis.ai.data.SecureStore
import com.jarvis.ai.skills.DarazCredentials
import com.jarvis.ai.skills.DarazException
import com.jarvis.ai.skills.SkillInfo
import com.jarvis.ai.voice.VoiceInput
import com.jarvis.ai.voice.VoiceOutput
import com.jarvis.ai.voice.WakeWordService
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

abstract class BaseVm(app: Application) : AndroidViewModel(app) {
    protected val c = (app as JarvisApp).container
    protected fun <T> Flow<T>.state(initial: T): StateFlow<T> =
        stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), initial)
}

class MainViewModel(app: Application) : BaseVm(app) {
    val messages = c.db.messageDao().observeAll().state(emptyList())
    val tasks = c.db.taskDao().observeAll().state(emptyList())
    val logs = c.db.logDao().observeRecent().state(emptyList())
    val pending = tasks.map { l -> l.firstOrNull { it.status == TaskStatus.PENDING_CONFIRMATION } }.state(null)
    val settings = c.settings.flow

    private val voiceIn = VoiceInput(app)
    private val voiceOut = VoiceOutput(app)
    private val listening = MutableStateFlow(false)
    private val thinking = MutableStateFlow(false)
    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error
    private val _partial = MutableStateFlow("")
    val partial: StateFlow<String> = _partial

    val status: StateFlow<AssistantStatus> =
        combine(listening, thinking, voiceOut.speaking, _error) { l, t, s, e ->
            when {
                l -> AssistantStatus.LISTENING
                t -> AssistantStatus.THINKING
                s -> AssistantStatus.SPEAKING
                e != null -> AssistantStatus.ERROR
                else -> AssistantStatus.IDLE
            }
        }.state(AssistantStatus.IDLE)

    fun setError(msg: String?) { _error.value = msg }

    fun send(text: String) {
        if (text.isBlank()) return
        viewModelScope.launch {
            _error.value = null
            thinking.value = true
            val result = try { c.engine.process(text) } finally { thinking.value = false }
            speakResult(result.text)
        }
    }

    private fun speakResult(text: String) {
        val s = c.settings.value
        if (s.speakReplies && text.isNotBlank()) {
            if (!voiceOut.speak(text, s.language.ttsTag(), s.speechRate, s.speechPitch)) {
                _error.value = "Text-to-speech isn't ready on this device."
            }
        }
    }

    fun startListening() {
        if (!voiceIn.isAvailable) {
            _error.value = "Speech recognition isn't available on this device."
            return
        }
        voiceOut.stop()
        _error.value = null
        _partial.value = ""
        listening.value = true
        voiceIn.start(
            languageTag = c.settings.value.language.sttTag(),
            onPartial = { _partial.value = it },
            onFinal = { text ->
                listening.value = false
                _partial.value = ""
                if (text.isNotBlank()) send(text)
            },
            onFailed = { _, msg ->
                listening.value = false
                _partial.value = ""
                _error.value = msg
            },
        )
    }

    fun stopListening() { voiceIn.stopListening() }
    fun stopSpeaking() { voiceOut.stop() }

    fun confirm(id: Long) = viewModelScope.launch {
        thinking.value = true
        val r = try { c.engine.confirm(id) } finally { thinking.value = false }
        speakResult(r.text)
    }
    fun cancel(id: Long) = viewModelScope.launch { c.engine.cancel(id) }
    fun retry(id: Long) = viewModelScope.launch {
        thinking.value = true
        val r = try { c.engine.retry(id) } finally { thinking.value = false }
        r?.let { speakResult(it.text) }
    }
    fun schedule(text: String, minutes: Long) = viewModelScope.launch { c.engine.scheduleReminder(text, minutes) }
    fun markDone(id: Long) = viewModelScope.launch { c.engine.markDone(id) }
    fun runDueCommand(id: Long, command: String) { markDone(id); send(command) }
    fun deleteTask(id: Long) = viewModelScope.launch { c.engine.deleteTask(id) }
    fun clearTasksAndLogs() = viewModelScope.launch { c.db.taskDao().clear(); c.db.logDao().clear() }

    override fun onCleared() {
        voiceIn.release()
        voiceOut.shutdown()
    }
}

class SkillsViewModel(app: Application) : BaseVm(app) {
    val skills: StateFlow<List<SkillInfo>> = c.registry.observeInfos().state(emptyList())
    fun setEnabled(id: String, on: Boolean) = viewModelScope.launch { c.registry.setEnabled(id, on) }
    fun remove(info: SkillInfo) = viewModelScope.launch { c.registry.remove(info) }
    fun restore() = viewModelScope.launch { c.registry.restoreBuiltIns() }
    fun add(name: String, desc: String, trigger: String, instruction: String) =
        viewModelScope.launch { c.registry.addCustom(name, desc, trigger, instruction) }
}

class SettingsViewModel(app: Application) : BaseVm(app) {
    val settings = c.settings.flow
    val memories = c.db.memoryDao().observeAll().state(emptyList())
    private val _hasKey = MutableStateFlow(c.secure.hasApiKey())
    val hasKey: StateFlow<Boolean> = _hasKey
    private val _message = MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = _message

    fun update(block: (AppSettings) -> AppSettings) = c.settings.update(block)

    fun saveKey(key: String) {
        try {
            c.secure.apiKey = key
            _hasKey.value = c.secure.hasApiKey()
            _message.value = if (_hasKey.value) "API key saved securely." else "API key cleared."
        } catch (e: Exception) {
            _message.value = "Couldn't store the key securely: ${e.message}"
        }
    }

    fun removeKey() = saveKey("")
    fun consumeMessage() { _message.value = null }

    fun setWakeWord(enabled: Boolean) {
        if (enabled && !WakeWordService.canRun(getApplication())) {
            _message.value = "Grant the microphone permission first."
            return
        }
        update { it.copy(wakeWordEnabled = enabled) }
        if (enabled) WakeWordService.start(getApplication()) else WakeWordService.stop(getApplication())
    }

    fun deleteMemory(id: Long) = viewModelScope.launch { c.db.memoryDao().delete(id) }
    fun clearMemory() = viewModelScope.launch { c.db.memoryDao().clear() }
    fun clearConversation() = viewModelScope.launch { c.db.messageDao().clear() }
    fun clearTasks() = viewModelScope.launch { c.db.taskDao().clear(); c.db.logDao().clear() }
    fun wipeAll() = viewModelScope.launch {
        WakeWordService.stop(getApplication())
        c.wipeEverything()
        _hasKey.value = false
        _message.value = "All JARVIS data was erased."
    }
}

enum class ConnStatus(val label: String) {
    UNAVAILABLE("Not available on this device"),
    AVAILABLE("Available (opens via Android)"),
    NEEDS_SETUP("Needs setup"),
    CONFIGURED("Credentials saved, not verified"),
    VERIFIED("Verified working"),
    ERROR("Check failed"),
}

data class AppConnection(val id: String, val name: String, val status: ConnStatus, val detail: String)

class AppsViewModel(app: Application) : BaseVm(app) {
    private val pm: PackageManager = app.packageManager
    private val _items = MutableStateFlow<List<AppConnection>>(emptyList())
    val items: StateFlow<List<AppConnection>> = _items
    private val _testing = MutableStateFlow(false)
    val testing: StateFlow<Boolean> = _testing
    private var darazError: String? = null

    init { refresh() }

    private fun canHandle(intent: Intent) = intent.resolveActivity(pm) != null

    private fun installed(pkg: String) = runCatching { pm.getPackageInfo(pkg, 0) }.isSuccess

    fun darazCreds() = DarazCredentials.from(c.secure)

    fun saveDaraz(appKey: String, secret: String, token: String) {
        c.secure.put(SecureStore.DARAZ_APP_KEY, appKey)
        c.secure.put(SecureStore.DARAZ_APP_SECRET, secret)
        c.secure.put(SecureStore.DARAZ_ACCESS_TOKEN, token)
        c.secure.remove(SecureStore.DARAZ_VERIFIED)
        darazError = null
        refresh()
    }

    fun clearDaraz() {
        listOf(SecureStore.DARAZ_APP_KEY, SecureStore.DARAZ_APP_SECRET, SecureStore.DARAZ_ACCESS_TOKEN, SecureStore.DARAZ_VERIFIED).forEach(c.secure::remove)
        darazError = null
        refresh()
    }

    fun testDaraz() = viewModelScope.launch {
        _testing.value = true
        try {
            c.darazApi.fetchOrders(darazCreds(), 1)
            c.secure.put(SecureStore.DARAZ_VERIFIED, "true")
            darazError = null
        } catch (e: DarazException) {
            c.secure.remove(SecureStore.DARAZ_VERIFIED)
            darazError = e.message
        } catch (e: Exception) {
            darazError = e.message ?: "Unknown error"
        } finally {
            _testing.value = false
            refresh()
        }
    }

    fun refresh() {
        val waPkg = listOf("com.whatsapp", "com.whatsapp.w4b").firstOrNull(::installed)
        val creds = darazCreds()
        val daraz = when {
            darazError != null -> AppConnection("daraz", "Daraz Seller Center", ConnStatus.ERROR, darazError!!)
            c.secure.get(SecureStore.DARAZ_VERIFIED) == "true" -> AppConnection("daraz", "Daraz Seller Center", ConnStatus.VERIFIED, "Open Platform API call succeeded. Orders are read-only.")
            creds.complete -> AppConnection("daraz", "Daraz Seller Center", ConnStatus.CONFIGURED, "Tap “Test connection” to verify.")
            else -> AppConnection("daraz", "Daraz Seller Center", ConnStatus.NEEDS_SETUP, "Seller Center opens in the browser without setup. Order summaries need Daraz Open Platform app key, secret and access token.")
        }
        _items.value = listOf(
            if (waPkg != null) AppConnection("whatsapp", "WhatsApp", ConnStatus.AVAILABLE, "Installed (${if (waPkg.endsWith("w4b")) "Business" else "standard"}). JARVIS prepares a draft; you press Send.")
            else AppConnection("whatsapp", "WhatsApp", ConnStatus.UNAVAILABLE, "WhatsApp isn't installed."),
            daraz,
            intentRow("browser", "Browser", Intent(Intent.ACTION_VIEW, Uri.parse("https://example.com")), "Opens links and searches."),
            intentRow("phone", "Phone", Intent(Intent.ACTION_DIAL, Uri.parse("tel:123")), "Opens the dialer; you press Call."),
            intentRow("sms", "SMS", Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:123")), "Opens a draft; you press Send."),
            intentRow("calendar", "Calendar", Intent(Intent.ACTION_INSERT).setData(CalendarContract.Events.CONTENT_URI), "Opens the new-event screen; cannot read your calendar."),
            intentRow("files", "Files", Intent(DownloadManager.ACTION_VIEW_DOWNLOADS), "Opens Downloads/Files; cannot read or search files."),
        )
    }

    private fun intentRow(id: String, name: String, intent: Intent, detail: String) =
        if (canHandle(intent)) AppConnection(id, name, ConnStatus.AVAILABLE, detail)
        else AppConnection(id, name, ConnStatus.UNAVAILABLE, "No app on this device handles this.")
}
