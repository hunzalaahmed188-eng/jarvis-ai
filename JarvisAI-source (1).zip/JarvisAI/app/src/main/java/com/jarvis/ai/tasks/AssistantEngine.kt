package com.jarvis.ai.tasks

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.Data
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.jarvis.ai.AppContainer
import com.jarvis.ai.JarvisApp
import com.jarvis.ai.ai.*
import com.jarvis.ai.core.TaskStatus
import com.jarvis.ai.data.ActionLogEntity
import com.jarvis.ai.data.MessageEntity
import com.jarvis.ai.data.TaskEntity
import com.jarvis.ai.skills.*
import java.util.concurrent.TimeUnit

sealed class EngineResult {
    abstract val text: String
    data class Reply(override val text: String, val pendingTaskId: Long? = null) : EngineResult()
    data class Error(override val text: String) : EngineResult()
}

/**
 * Central brain: routes text to skills first, falls back to the AI model, records tasks and logs.
 * Used by both the UI (MainViewModel) and the wake-word service.
 */
class AssistantEngine(private val c: AppContainer) {
    private val db get() = c.db

    private fun skillContext(): SkillContext {
        val s = c.settings.value
        return SkillContext(
            appContext = c.app,
            secure = c.secure,
            memory = db.memoryDao(),
            language = s.language,
            defaultCountryCode = s.defaultCountryCode,
            ask = { system, user -> askRaw(system, user) },
        )
    }

    private suspend fun askRaw(system: String, user: String): String {
        val key = c.secure.apiKey
        if (key.isBlank()) throw AiException("No API key set. Open Settings → AI provider and add your key.")
        val s = c.settings.value
        val payload = ChatPayload.build(s.model, system, listOf(ChatTurn("user", user)))
        return c.aiClient.chat(s.endpoint, key, payload)
    }

    suspend fun log(taskId: Long?, message: String) {
        db.logDao().insert(ActionLogEntity(taskId = taskId, message = message))
    }

    private suspend fun record(role: String, text: String) {
        db.messageDao().insert(MessageEntity(role = role, content = text))
    }

    private suspend fun reply(text: String, pending: Long? = null): EngineResult {
        record("assistant", text)
        return EngineResult.Reply(text, pending)
    }

    private suspend fun error(text: String): EngineResult {
        record("error", text)
        return EngineResult.Error(text)
    }

    /** [headless] = no UI in front of the user (wake-word service): risky or UI-launching actions are queued for review. */
    suspend fun process(text: String, headless: Boolean = false): EngineResult {
        val input = text.trim()
        if (input.isEmpty()) return EngineResult.Reply("")
        record("user", input)
        return try {
            val ctx = skillContext()
            for (skill in c.registry.enabledSkills()) {
                when (val plan = skill.plan(input, ctx)) {
                    SkillPlan.NotHandled -> continue
                    is SkillPlan.Reply -> return reply(plan.text)
                    is SkillPlan.Act -> return handleAction(skill, plan, headless)
                }
            }
            askModel(input)
        } catch (e: AiException) {
            error(e.message ?: "AI error")
        } catch (e: Exception) {
            error("Something went wrong: ${e.message ?: e.javaClass.simpleName}")
        }
    }

    private suspend fun handleAction(skill: Skill, plan: SkillPlan.Act, headless: Boolean): EngineResult {
        val a = plan.action
        val needsReview = a.sensitive || (headless && a.launchesUi)
        val taskId = db.taskDao().insert(
            TaskEntity(
                title = a.summary, skillId = a.skillId, actionId = a.actionId,
                paramsJson = ParamsJson.encode(a.params), sensitive = a.sensitive, launchesUi = a.launchesUi,
                status = if (needsReview) TaskStatus.PENDING_CONFIRMATION else TaskStatus.RUNNING,
            )
        )
        if (needsReview) {
            log(taskId, "Awaiting your confirmation: ${a.summary}")
            if (headless) c.notifier.notifyTask("JARVIS needs your confirmation", a.summary)
            val lead = plan.reply?.let { "$it\n\n" }.orEmpty()
            return reply("${lead}Waiting for your confirmation: ${a.summary}", taskId)
        }
        return runTask(taskId)
    }

    /** Executes a stored task. Only call for tasks that are non-sensitive or already confirmed. */
    private suspend fun runTask(taskId: Long): EngineResult {
        val t = db.taskDao().get(taskId) ?: return error("Task not found.")
        db.taskDao().update(t.copy(status = TaskStatus.RUNNING, attempts = t.attempts + 1, lastError = null))
        log(taskId, "Started: ${t.title}")
        val skill = c.registry.find(t.skillId)
        val outcome = if (skill == null) SkillOutcome(false, "The skill for this task is no longer installed.") else try {
            skill.execute(
                PlannedAction(t.skillId, t.actionId, ParamsJson.decode(t.paramsJson), t.title, t.sensitive, t.launchesUi),
                skillContext(),
            )
        } catch (e: AiException) {
            SkillOutcome(false, e.message ?: "AI error")
        } catch (e: Exception) {
            SkillOutcome(false, "Failed: ${e.message ?: e.javaClass.simpleName}")
        }
        val latest = db.taskDao().get(taskId) ?: t
        db.taskDao().update(
            latest.copy(
                status = if (outcome.success) TaskStatus.SUCCESS else TaskStatus.FAILED,
                lastError = if (outcome.success) null else outcome.message,
            )
        )
        log(taskId, (if (outcome.success) "Completed: " else "Failed: ") + outcome.message.lineSequence().first().take(200))
        return if (outcome.success) reply(outcome.message) else error(outcome.message)
    }

    suspend fun confirm(taskId: Long): EngineResult {
        val t = db.taskDao().get(taskId) ?: return error("Task not found.")
        if (t.status != TaskStatus.PENDING_CONFIRMATION) return EngineResult.Reply("")
        log(taskId, "You confirmed: ${t.title}")
        return runTask(taskId)
    }

    suspend fun cancel(taskId: Long) {
        val t = db.taskDao().get(taskId) ?: return
        db.taskDao().update(t.copy(status = TaskStatus.CANCELLED))
        WorkManager.getInstance(c.app).cancelUniqueWork("task-$taskId")
        log(taskId, "Cancelled: ${t.title}")
    }

    /** Safe retry: capped attempts; sensitive tasks must be confirmed again. */
    suspend fun retry(taskId: Long): EngineResult? {
        val t = db.taskDao().get(taskId) ?: return null
        if (t.status != TaskStatus.FAILED || t.attempts >= TaskStatus.MAX_ATTEMPTS) return null
        return if (t.sensitive) {
            db.taskDao().update(t.copy(status = TaskStatus.PENDING_CONFIRMATION))
            log(taskId, "Retry requested; waiting for confirmation: ${t.title}")
            null
        } else {
            log(taskId, "Retrying (attempt ${t.attempts + 1}/${TaskStatus.MAX_ATTEMPTS}): ${t.title}")
            runTask(taskId)
        }
    }

    private suspend fun askModel(input: String): EngineResult {
        val key = c.secure.apiKey
        if (key.isBlank()) return error("No API key set. Open Settings → AI provider and add your key to chat with the AI. (Local commands like \"search …\" or \"WhatsApp <number> saying …\" work without one.)")
        val s = c.settings.value
        val history = db.messageDao().recent(20).reversed()
            .filter { it.role == "user" || it.role == "assistant" }
            .map { ChatTurn(it.role, it.content) }
        val memories = if (s.memoryEnabled) db.memoryDao().getAll().map { it.text } else emptyList()
        val system = PromptBuilder.system(s.language, memories, c.registry.enabledSkills().map { it.name })
        val answer = c.aiClient.chat(s.endpoint, key, ChatPayload.build(s.model, system, history))
        return reply(answer)
    }

    suspend fun scheduleReminder(commandOrTitle: String, delayMinutes: Long) {
        val due = System.currentTimeMillis() + TimeUnit.MINUTES.toMillis(delayMinutes)
        val id = db.taskDao().insert(
            TaskEntity(title = commandOrTitle, skillId = "reminder", actionId = "remind", status = TaskStatus.SCHEDULED, scheduledAt = due)
        )
        val req = OneTimeWorkRequestBuilder<ScheduledTaskWorker>()
            .setInitialDelay(delayMinutes, TimeUnit.MINUTES)
            .setInputData(Data.Builder().putLong("taskId", id).build())
            .build()
        WorkManager.getInstance(c.app).enqueueUniqueWork("task-$id", androidx.work.ExistingWorkPolicy.REPLACE, req)
        log(id, "Scheduled for ${java.text.DateFormat.getTimeInstance(java.text.DateFormat.SHORT).format(java.util.Date(due))}: $commandOrTitle")
    }

    suspend fun markDone(taskId: Long) {
        val t = db.taskDao().get(taskId) ?: return
        db.taskDao().update(t.copy(status = TaskStatus.SUCCESS))
        log(taskId, "Marked done: ${t.title}")
    }

    suspend fun deleteTask(taskId: Long) {
        WorkManager.getInstance(c.app).cancelUniqueWork("task-$taskId")
        db.taskDao().delete(taskId)
    }
}

/** Fires a reminder notification. WorkManager timing is approximate (Doze / battery optimisation may delay it). */
class ScheduledTaskWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result {
        val c = (applicationContext as JarvisApp).container
        val id = inputData.getLong("taskId", -1)
        val t = c.db.taskDao().get(id) ?: return Result.success()
        if (t.status != TaskStatus.SCHEDULED) return Result.success()
        c.db.taskDao().update(t.copy(status = TaskStatus.DUE))
        c.engine.log(id, "Reminder due: ${t.title}")
        c.notifier.notifyTask("JARVIS reminder", t.title)
        return Result.success()
    }
}
