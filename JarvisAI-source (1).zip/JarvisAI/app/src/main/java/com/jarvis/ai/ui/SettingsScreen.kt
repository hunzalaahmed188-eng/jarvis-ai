package com.jarvis.ai.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.jarvis.ai.core.LanguageMode
import com.jarvis.ai.core.ThemeMode

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(nav: NavController, vm: SettingsViewModel = viewModel()) {
    val s by vm.settings.collectAsStateWithLifecycle()
    val hasKey by vm.hasKey.collectAsStateWithLifecycle()
    val message by vm.message.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val snackbar = remember { SnackbarHostState() }
    var keyInput by remember { mutableStateOf("") }
    var endpoint by remember(s.endpoint) { mutableStateOf(s.endpoint) }
    var model by remember(s.model) { mutableStateOf(s.model) }
    var provider by remember(s.providerName) { mutableStateOf(s.providerName) }
    var wake by remember(s.wakeWord) { mutableStateOf(s.wakeWord) }
    var cc by remember(s.defaultCountryCode) { mutableStateOf(s.defaultCountryCode) }
    var confirmWipe by remember { mutableStateOf(false) }
    var micGranted by remember { mutableStateOf(ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) }
    var notifGranted by remember { mutableStateOf(android.os.Build.VERSION.SDK_INT < 33 || ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) }

    val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { micGranted = it }
    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { notifGranted = it }

    LaunchedEffect(message) { message?.let { snackbar.showSnackbar(it); vm.consumeMessage() } }

    Scaffold(
        topBar = { ScreenTopBar("Settings", nav) },
        snackbarHost = { SnackbarHost(snackbar) },
    ) { pad ->
        Column(Modifier.padding(pad).padding(horizontal = 16.dp).verticalScroll(rememberScrollState())) {
            SectionTitle("AI provider")
            Text("Works with OpenAI-compatible chat-completions endpoints. Your key is stored encrypted on this device and sent only to the endpoint below.", style = MaterialTheme.typography.bodySmall)
            OutlinedTextField(provider, { provider = it }, label = { Text("Provider name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(endpoint, { endpoint = it }, label = { Text("Endpoint (https://…/chat/completions)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(model, { model = it }, label = { Text("Model") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Button(onClick = { vm.update { it.copy(providerName = provider.trim(), endpoint = endpoint.trim(), model = model.trim()) } }, modifier = Modifier.padding(top = 6.dp)) { Text("Save provider settings") }

            SectionTitle("API key")
            Text(if (hasKey) "A key is saved (hidden)." else "No key saved.", color = if (hasKey) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
            OutlinedTextField(keyInput, { keyInput = it }, label = { Text("Paste API key") }, singleLine = true,
                visualTransformation = PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password), modifier = Modifier.fillMaxWidth())
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 6.dp)) {
                Button(enabled = keyInput.isNotBlank(), onClick = { vm.saveKey(keyInput); keyInput = "" }) { Text("Save key") }
                OutlinedButton(enabled = hasKey, onClick = vm::removeKey) { Text("Remove key") }
            }

            SectionTitle("Language")
            LanguageMode.entries.forEach { m ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(selected = s.language == m, onClick = { vm.update { it.copy(language = m) } })
                    Text(m.label)
                }
            }
            OutlinedTextField(cc, { cc = it.filter(Char::isDigit) }, label = { Text("Default country code for phone numbers") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            TextButton(onClick = { if (cc.isNotBlank()) vm.update { it.copy(defaultCountryCode = cc) } }) { Text("Save country code") }

            SectionTitle("Voice")
            LabeledSwitch("Speak replies", "Uses Android text-to-speech (Urdu needs an installed Urdu voice).", s.speakReplies) { v -> vm.update { it.copy(speakReplies = v) } }
            Text("Speech speed: ${"%.1f".format(s.speechRate)}×")
            Slider(value = s.speechRate, onValueChange = { v -> vm.update { it.copy(speechRate = v) } }, valueRange = 0.5f..2f)
            Text("Pitch: ${"%.1f".format(s.speechPitch)}")
            Slider(value = s.speechPitch, onValueChange = { v -> vm.update { it.copy(speechPitch = v) } }, valueRange = 0.5f..2f)
            LabeledSwitch("Wake word (experimental)", "Keeps a notification-backed microphone service running and listens for the wake word.", s.wakeWordEnabled) { vm.setWakeWord(it) }
            OutlinedTextField(wake, { wake = it }, label = { Text("Wake word") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            TextButton(onClick = { if (wake.isNotBlank()) vm.update { it.copy(wakeWord = wake.trim()) } }) { Text("Save wake word") }
            Card(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                Text(
                    "Android battery & background limits: the wake word is not an on-device keyword detector. It repeatedly runs Android's speech recognizer inside a foreground service, which uses battery and may send audio to your device's speech provider. Android 12+ only lets this service start while JARVIS is on screen, and phone-maker battery savers (Xiaomi, Oppo, Vivo, Samsung…) may stop it; exclude JARVIS from battery optimisation if needed. Commands that open other apps are queued for your review because Android blocks background app launches. Always-on listening is not available when the app is force-stopped.",
                    style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(12.dp),
                )
            }

            SectionTitle("Theme")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ThemeMode.entries.forEach { m ->
                    FilterChip(selected = s.theme == m, onClick = { vm.update { it.copy(theme = m) } }, label = { Text(m.name.lowercase().replaceFirstChar(Char::uppercase)) })
                }
            }

            SectionTitle("Notifications")
            LabeledSwitch("Task reminders & confirmations", "Shown when a reminder is due or a background request needs your OK.", s.notificationsEnabled) { v -> vm.update { it.copy(notificationsEnabled = v) } }

            SectionTitle("Permissions")
            PermissionRow("Microphone", "Speech-to-text and the optional wake word.", micGranted,
                onRequest = { micLauncher.launch(Manifest.permission.RECORD_AUDIO) },
                onOpenSettings = { context.startActivity(appSettingsIntent(context)) })
            PermissionRow("Notifications", "Reminders and confirmation prompts (Android 13+).", notifGranted,
                onRequest = { notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS) },
                onOpenSettings = { context.startActivity(appSettingsIntent(context)) })
            Text("JARVIS requests no contacts, SMS, call, calendar or storage permissions: those skills hand a draft to the system apps so you stay in control.", style = MaterialTheme.typography.bodySmall)

            SectionTitle("Privacy & memory")
            LabeledSwitch("Save conversation history", "When off, the history is erased each time the app starts.", s.saveHistory) { v -> vm.update { it.copy(saveHistory = v) } }
            LabeledSwitch("Use memory in AI replies", "Sends your saved preferences to the AI provider as context.", s.memoryEnabled) { v -> vm.update { it.copy(memoryEnabled = v) } }
            Text("Your messages are sent to the endpoint you configured. Nothing is sent to the app developer.", style = MaterialTheme.typography.bodySmall)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { nav.navigate("memory") }) { Text("View memory") }
                OutlinedButton(onClick = vm::clearConversation) { Text("Clear chat") }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = vm::clearTasks) { Text("Clear tasks & logs") }
                Button(onClick = { confirmWipe = true }, colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)) { Text("Erase all data") }
            }

            SectionTitle("More")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { nav.navigate("apps") }) { Text("Connected apps") }
                OutlinedButton(onClick = { nav.navigate("skills") }) { Text("Skills") }
            }
            Spacer(Modifier.height(32.dp))
        }
    }

    if (confirmWipe) {
        AlertDialog(
            onDismissRequest = { confirmWipe = false },
            title = { Text("Erase everything?") },
            text = { Text("This deletes the conversation, memory, tasks, logs, custom skills, saved API key, Daraz credentials and all settings. It can't be undone.") },
            confirmButton = { TextButton(onClick = { vm.wipeAll(); confirmWipe = false }) { Text("Erase") } },
            dismissButton = { TextButton(onClick = { confirmWipe = false }) { Text("Cancel") } },
        )
    }
}

private fun appSettingsIntent(context: android.content.Context) =
    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", context.packageName, null))

@Composable
private fun PermissionRow(name: String, why: String, granted: Boolean, onRequest: () -> Unit, onOpenSettings: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text("$name — ${if (granted) "granted" else "not granted"}")
            Text(why, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        if (!granted) TextButton(onClick = onRequest) { Text("Allow") }
        TextButton(onClick = onOpenSettings) { Text("System") }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ScreenTopBar(title: String, nav: NavController) {
    TopAppBar(
        title = { Text(title) },
        navigationIcon = {
            IconButton(onClick = { nav.popBackStack() }) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back")
            }
        },
    )
}

@Composable
fun MemoryScreen(nav: NavController, vm: SettingsViewModel = viewModel()) {
    val memories by vm.memories.collectAsStateWithLifecycle()
    ScreenScaffold("Memory", nav, actions = { TextButton(onClick = vm::clearMemory) { Text("Clear all") } }) { pad ->
        LazyColumn(Modifier.padding(pad).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            item { Text("Only things you explicitly asked JARVIS to remember (and confirmed) are stored here.", style = MaterialTheme.typography.bodySmall) }
            if (memories.isEmpty()) item { Text("Nothing saved. Say “remember that …”.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
            items(memories, key = { it.id }) { m ->
                Card(Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(start = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(m.text, Modifier.weight(1f))
                        IconButton(onClick = { vm.deleteMemory(m.id) }) { Icon(Icons.Default.Delete, "Delete memory") }
                    }
                }
            }
        }
    }
}
