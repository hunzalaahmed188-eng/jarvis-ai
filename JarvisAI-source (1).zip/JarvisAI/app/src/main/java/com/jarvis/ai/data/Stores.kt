package com.jarvis.ai.data

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.jarvis.ai.core.AppSettings
import com.jarvis.ai.core.LanguageMode
import com.jarvis.ai.core.ThemeMode
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/**
 * Secrets (AI API key, Daraz credentials) are stored with EncryptedSharedPreferences,
 * whose keys are protected by the Android Keystore. Nothing is hard-coded or logged.
 */
class SecureStore(private val context: Context) {
    private val prefs by lazy {
        val masterKey = MasterKey.Builder(context)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
        EncryptedSharedPreferences.create(
            context,
            "jarvis_secure",
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM,
        )
    }

    fun get(key: String): String = runCatching { prefs.getString(key, "") ?: "" }.getOrDefault("")
    fun put(key: String, value: String) = prefs.edit().putString(key, value.trim()).apply()
    fun remove(key: String) = prefs.edit().remove(key).apply()
    fun clearAll() = prefs.edit().clear().apply()

    var apiKey: String
        get() = get(API_KEY)
        set(v) = put(API_KEY, v)

    fun hasApiKey() = apiKey.isNotBlank()

    companion object {
        const val API_KEY = "ai_api_key"
        const val DARAZ_APP_KEY = "daraz_app_key"
        const val DARAZ_APP_SECRET = "daraz_app_secret"
        const val DARAZ_ACCESS_TOKEN = "daraz_access_token"
        const val DARAZ_VERIFIED = "daraz_verified"
    }
}

class SettingsStore(context: Context) {
    private val prefs = context.getSharedPreferences("jarvis_settings", Context.MODE_PRIVATE)
    private val _flow = MutableStateFlow(load())
    val flow: StateFlow<AppSettings> = _flow
    val value: AppSettings get() = _flow.value

    fun update(block: (AppSettings) -> AppSettings) {
        val next = block(_flow.value)
        save(next)
        _flow.value = next
    }

    fun reset() {
        prefs.edit().clear().apply()
        _flow.value = AppSettings()
    }

    private fun load(): AppSettings {
        val d = AppSettings()
        return AppSettings(
            providerName = prefs.getString("provider", d.providerName) ?: d.providerName,
            endpoint = prefs.getString("endpoint", d.endpoint) ?: d.endpoint,
            model = prefs.getString("model", d.model) ?: d.model,
            language = LanguageMode.fromName(prefs.getString("language", null)),
            speakReplies = prefs.getBoolean("speak", d.speakReplies),
            speechRate = prefs.getFloat("rate", d.speechRate),
            speechPitch = prefs.getFloat("pitch", d.speechPitch),
            theme = ThemeMode.fromName(prefs.getString("theme", null)),
            wakeWordEnabled = prefs.getBoolean("wake_enabled", d.wakeWordEnabled),
            wakeWord = prefs.getString("wake_word", d.wakeWord) ?: d.wakeWord,
            notificationsEnabled = prefs.getBoolean("notif", d.notificationsEnabled),
            saveHistory = prefs.getBoolean("save_history", d.saveHistory),
            memoryEnabled = prefs.getBoolean("memory", d.memoryEnabled),
            defaultCountryCode = prefs.getString("cc", d.defaultCountryCode) ?: d.defaultCountryCode,
        )
    }

    private fun save(s: AppSettings) {
        prefs.edit()
            .putString("provider", s.providerName)
            .putString("endpoint", s.endpoint)
            .putString("model", s.model)
            .putString("language", s.language.name)
            .putBoolean("speak", s.speakReplies)
            .putFloat("rate", s.speechRate)
            .putFloat("pitch", s.speechPitch)
            .putString("theme", s.theme.name)
            .putBoolean("wake_enabled", s.wakeWordEnabled)
            .putString("wake_word", s.wakeWord)
            .putBoolean("notif", s.notificationsEnabled)
            .putBoolean("save_history", s.saveHistory)
            .putBoolean("memory", s.memoryEnabled)
            .putString("cc", s.defaultCountryCode)
            .apply()
    }
}
