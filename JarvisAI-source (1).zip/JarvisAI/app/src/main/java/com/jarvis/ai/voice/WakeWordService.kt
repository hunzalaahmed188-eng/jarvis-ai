package com.jarvis.ai.voice

import android.Manifest
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.jarvis.ai.JarvisApp
import com.jarvis.ai.tasks.Notifier
import kotlinx.coroutines.*

/**
 * EXPERIMENTAL wake word: a microphone foreground service that repeatedly runs Android's
 * SpeechRecognizer and looks for the wake word ("jarvis") in the transcript.
 *
 * This is NOT an on-device keyword spotter. Limitations (also shown in Settings):
 *  - Many recognizers beep or send audio to the network; battery use is noticeable.
 *  - Android 12+ forbids starting a microphone foreground service from the background, so it can only be
 *    started while the app is on screen. OEM battery managers may still kill it.
 *  - Because background activity launches are blocked, commands that open other apps are queued for
 *    your review (you get a notification). Sensitive actions always need confirmation.
 */
class WakeWordService : Service() {
    companion object {
        const val ACTION_STOP = "com.jarvis.ai.STOP_WAKE_WORD"

        fun start(context: Context) {
            ContextCompat.startForegroundService(context, Intent(context, WakeWordService::class.java))
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, WakeWordService::class.java))
        }

        fun canRun(context: Context) =
            ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private lateinit var voiceIn: VoiceInput
    private lateinit var voiceOut: VoiceOutput
    private var running = false
    private var awaitingCommand = false

    private val container get() = (application as JarvisApp).container

    override fun onCreate() {
        super.onCreate()
        voiceIn = VoiceInput(this)
        voiceOut = VoiceOutput(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            container.settings.update { it.copy(wakeWordEnabled = false) }
            stopSelf()
            return START_NOT_STICKY
        }
        if (!canRun(this) || !voiceIn.isAvailable) {
            stopSelf()
            return START_NOT_STICKY
        }
        val stopPi = PendingIntent.getService(
            this, 1, Intent(this, WakeWordService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val type = if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE else 0
        try {
            ServiceCompat.startForeground(this, Notifier.SERVICE_NOTIFICATION_ID, container.notifier.serviceNotification(stopPi), type)
        } catch (e: Exception) {
            // Android refused to start a microphone foreground service (e.g. from the background).
            stopSelf()
            return START_NOT_STICKY
        }
        if (!running) {
            running = true
            listen()
        }
        return START_NOT_STICKY
    }

    private fun listen() {
        if (!running) return
        val s = container.settings.value
        voiceIn.start(
            languageTag = s.language.sttTag(),
            onPartial = {},
            onFinal = { handle(it) },
            onFailed = { code, _ ->
                if (code == android.speech.SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) stopSelf()
                else restartSoon(if (SpeechErrors.isQuiet(code)) 300 else 2000)
            },
        )
    }

    private fun restartSoon(delayMs: Long) {
        scope.launch { delay(delayMs); listen() }
    }

    private fun handle(text: String) {
        val s = container.settings.value
        val wake = s.wakeWord.trim().lowercase()
        val lower = text.lowercase()
        when {
            awaitingCommand -> { awaitingCommand = false; runCommand(text) }
            wake.isNotEmpty() && lower.contains(wake) -> {
                val cmd = text.substring(lower.indexOf(wake) + wake.length).trim(' ', ',', '.', '!')
                if (cmd.isEmpty()) {
                    awaitingCommand = true
                    speak("Yes?")
                    restartSoon(1500)
                } else runCommand(cmd)
            }
            else -> restartSoon(300)
        }
    }

    private fun runCommand(cmd: String) {
        scope.launch {
            val result = container.engine.process(cmd, headless = true)
            speak(result.text)
            restartSoon(2500)
        }
    }

    private fun speak(text: String) {
        val s = container.settings.value
        if (s.speakReplies) voiceOut.speak(text, s.language.ttsTag(), s.speechRate, s.speechPitch)
    }

    override fun onDestroy() {
        running = false
        scope.cancel()
        voiceIn.release()
        voiceOut.shutdown()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
