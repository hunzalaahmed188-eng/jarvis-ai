package com.jarvis.ai.skills

import android.content.Context
import android.content.Intent
import com.jarvis.ai.core.LanguageMode
import com.jarvis.ai.data.MemoryDao
import com.jarvis.ai.data.SecureStore
import org.json.JSONObject

/**
 * ============================  SKILL DEVELOPER API  ============================
 *
 * To add a skill:
 *  1. Implement [Skill] (see BuiltInSkills.kt for examples).
 *  2. Register the instance in AppContainer.builtInSkills (JarvisApp.kt).
 *  3. Done: it appears in the Skills screen with its permissions and required apps.
 *
 * Contract:
 *  - plan(): inspect the user's text. Return NotHandled if it isn't yours, Reply to answer
 *    directly, or Act to propose an action. NEVER perform side effects in plan().
 *  - Mark an action `sensitive = true` if it sends/shares/deletes/spends. The engine will then
 *    store it as PENDING_CONFIRMATION and run it only after the user taps Confirm.
 *  - Mark `launchesUi = true` if execute() starts another app's screen. Background (wake-word)
 *    requests are queued for review because Android blocks background activity launches.
 *  - execute(): perform the action and return a [SkillOutcome]. Throw or return success=false on failure;
 *    the engine records status, logs and allows safe retry.
 *  - List honestly what you need in [requiredApps] and [permissions].
 * ==============================================================================
 */
interface Skill {
    val id: String
    val name: String
    val description: String
    val requiredApps: List<String>
    val permissions: List<SkillPermission>

    suspend fun plan(input: String, ctx: SkillContext): SkillPlan
    suspend fun execute(action: PlannedAction, ctx: SkillContext): SkillOutcome
}

data class SkillPermission(val name: String, val reason: String)

data class PlannedAction(
    val skillId: String,
    val actionId: String,
    val params: Map<String, String>,
    val summary: String,
    val sensitive: Boolean,
    val launchesUi: Boolean,
)

sealed class SkillPlan {
    object NotHandled : SkillPlan()
    data class Reply(val text: String) : SkillPlan()
    data class Act(val action: PlannedAction, val reply: String? = null) : SkillPlan()
}

data class SkillOutcome(val success: Boolean, val message: String)

class SkillContext(
    val appContext: Context,
    val secure: SecureStore,
    val memory: MemoryDao,
    val language: LanguageMode,
    val defaultCountryCode: String,
    /** Ask the configured AI model (system prompt, user text). Throws AiException on failure. */
    val ask: suspend (system: String, user: String) -> String,
)

object ParamsJson {
    fun encode(map: Map<String, String>): String = JSONObject(map).toString()
    fun decode(json: String): Map<String, String> = runCatching {
        val o = JSONObject(json)
        o.keys().asSequence().associateWith { o.getString(it) }
    }.getOrDefault(emptyMap())
}

object IntentLauncher {
    fun launch(context: Context, intent: Intent, okMessage: String): SkillOutcome =
        try {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            SkillOutcome(true, okMessage)
        } catch (e: android.content.ActivityNotFoundException) {
            SkillOutcome(false, "No app on this device can handle that action.")
        } catch (e: SecurityException) {
            SkillOutcome(false, "Android blocked the action: ${e.message}")
        }
}
