package com.jarvis.ai.skills

import java.net.URLEncoder

/** Pure parsing helpers (unit tested). */
object PhoneNumbers {
    private val phoneRegex = Regex("""\+?\d[\d\s\-()]{5,}\d""")

    fun find(input: String): String? = phoneRegex.find(input)?.value

    /** Returns digits-only international number (no '+'), or null if it can't be a phone number. */
    fun toInternational(raw: String, defaultCountryCode: String = "92"): String? {
        val trimmed = raw.trim()
        val digits = trimmed.filter { it.isDigit() }
        if (digits.length < 7) return null
        return when {
            trimmed.startsWith("+") -> digits
            digits.startsWith("00") -> digits.drop(2)
            digits.startsWith("0") -> defaultCountryCode + digits.drop(1)
            else -> digits
        }
    }
}

object MessageParser {
    private val lead = Regex("^(?:saying|say|that says|that|message|msg|with message|:|-|,)\\s*", RegexOption.IGNORE_CASE)

    /** Text following the phone number, minus filler words like "saying". */
    fun bodyAfter(input: String, phone: String): String {
        val idx = input.indexOf(phone)
        var rest = if (idx >= 0) input.substring(idx + phone.length) else ""
        rest = rest.trim()
        var changed = true
        while (changed) {
            val next = lead.replace(rest, "").trim()
            changed = next != rest
            rest = next
        }
        return rest.trim('"', '\u201C', '\u201D', '\'').trim()
    }
}

object WhatsAppLinks {
    fun encode(s: String): String = URLEncoder.encode(s, "UTF-8").replace("+", "%20")

    fun chatUrl(internationalNumber: String, text: String?): String {
        val base = "https://wa.me/$internationalNumber"
        return if (text.isNullOrBlank()) base else "$base?text=${encode(text)}"
    }
}

object UrlDetector {
    private val explicit = Regex("""https?://\S+""", RegexOption.IGNORE_CASE)
    private val domain = Regex("""\b[a-z0-9-]+(?:\.[a-z0-9-]+)*\.(?:com|pk|org|net|io|co|edu|gov|info|app)\b(?:/\S*)?""", RegexOption.IGNORE_CASE)

    fun findUrl(input: String): String? {
        explicit.find(input)?.let { return it.value }
        domain.find(input)?.let { return "https://${it.value}" }
        return null
    }

    private val verbs = Regex("^(?:please\\s+)?(?:search(?:\\s+for)?|google|browse|look\\s+up|find|open|go\\s+to)\\s+", RegexOption.IGNORE_CASE)

    fun searchQuery(input: String): String = verbs.replace(input.trim(), "").trim()

    fun searchUrl(query: String): String = "https://www.google.com/search?q=${WhatsAppLinks.encode(query)}"
}
