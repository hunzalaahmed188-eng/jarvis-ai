package com.jarvis.ai.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import com.jarvis.ai.core.ThemeMode

val JarvisCyan = Color(0xFF00E5FF)
val JarvisAmber = Color(0xFFFFB300)

private val Dark = darkColorScheme(
    primary = JarvisCyan,
    onPrimary = Color(0xFF00363D),
    primaryContainer = Color(0xFF004F58),
    onPrimaryContainer = Color(0xFFB8F3FF),
    secondary = JarvisAmber,
    background = Color(0xFF0A0F1A),
    onBackground = Color(0xFFE3F2F6),
    surface = Color(0xFF0F1726),
    onSurface = Color(0xFFE3F2F6),
    surfaceVariant = Color(0xFF16223A),
    onSurfaceVariant = Color(0xFFB4C7D0),
)

private val Light = lightColorScheme(
    primary = Color(0xFF006874),
    secondary = Color(0xFF8A5100),
)

@Composable
fun JarvisTheme(mode: ThemeMode, content: @Composable () -> Unit) {
    val dark = when (mode) {
        ThemeMode.DARK -> true
        ThemeMode.LIGHT -> false
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
    }
    MaterialTheme(colorScheme = if (dark) Dark else Light, content = content)
}
