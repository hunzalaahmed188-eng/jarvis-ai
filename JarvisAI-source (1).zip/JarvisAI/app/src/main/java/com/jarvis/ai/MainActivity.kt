package com.jarvis.ai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.jarvis.ai.ui.*
import com.jarvis.ai.ui.theme.JarvisTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val container = (application as JarvisApp).container
        setContent {
            val settings by container.settings.flow.collectAsStateWithLifecycle()
            JarvisTheme(settings.theme) {
                Surface(color = MaterialTheme.colorScheme.background) {
                    val nav = rememberNavController()
                    val main: MainViewModel = viewModel()
                    val pending by main.pending.collectAsStateWithLifecycle()

                    NavHost(navController = nav, startDestination = "dashboard") {
                        composable("dashboard") { DashboardScreen(main, nav) }
                        composable("skills") { SkillsScreen(nav) }
                        composable("apps") { AppsScreen(nav) }
                        composable("tasks") { TasksScreen(main, nav) }
                        composable("settings") { SettingsScreen(nav) }
                        composable("memory") { MemoryScreen(nav) }
                    }

                    // Global confirmation gate: nothing sensitive runs until you tap Confirm.
                    pending?.let { task ->
                        AlertDialog(
                            onDismissRequest = { /* must choose explicitly */ },
                            title = { Text("Confirm action") },
                            text = {
                                Text(
                                    task.title + if (task.launchesUi && task.sensitive)
                                        "\n\nThis opens another app with a draft. You'll still review it and press Send there."
                                    else ""
                                )
                            },
                            confirmButton = { Button(onClick = { main.confirm(task.id) }) { Text("Confirm") } },
                            dismissButton = { TextButton(onClick = { main.cancel(task.id) }) { Text("Cancel") } },
                        )
                    }
                }
            }
        }
    }
}
