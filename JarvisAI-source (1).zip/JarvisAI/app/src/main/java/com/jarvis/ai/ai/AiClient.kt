package com.jarvis.ai.ai

import com.jarvis.ai.core.LanguageMode
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import java.io.IOException
import java.net.SocketTimeoutException
import java.net.UnknownHostException

class AiException(message: String) : Exception(message)

data class ChatTurn(val role: String, val content: String)

/** Pure helpers for OpenAI-compatible /chat/completions payloads (unit tested). */
object ChatPayload {
    fun build(model: String, system: String, history: List<ChatTurn>, temperature: Double = 0.7): String {
        val messages = JSONArray()
        messages.put(JSONObject().put("role", "system").put("content", system))
        history.forEach { messages.put(JSONObject().put("role", it.role).put("content", it.content)) }
        return JSONObject()
            .put("model", model)
            .put("temperature", temperature)
            .put("messages", messages)
            .toString()
    }

    fun parseReply(body: String): String {
        try {
            val content = JSONObject(body)
                .getJSONArray("choices").getJSONObject(0)
                .getJSONObject("message").getString("content")
            if (content.isBlank()) throw AiException("The AI returned an empty answer.")
            return content.trim()
        } catch (e: JSONException) {
            throw AiException("Unexpected response from the AI provider.")
        }
    }

    fun describeHttpError(code: Int, body: String): String {
        val detail = runCatching {
            JSONObject(body).getJSONObject("error").getString("message")
        }.getOrNull()
        val base = when (code) {
            400 -> "The provider rejected the request (400). Check the model name."
            401, 403 -> "The API key was rejected ($code). Check it in Settings."
            404 -> "Endpoint or model not found (404). Check the endpoint URL and model name."
            429 -> "Rate limit or quota reached (429). Try again later or check your plan."
            in 500..599 -> "The AI provider had a server error ($code). Try again shortly."
            else -> "Unexpected response from the provider (HTTP $code)."
        }
        return if (detail.isNullOrBlank()) base else "$base\n$detail"
    }
}

object PromptBuilder {
    fun system(language: LanguageMode, memories: List<String>, skillNames: List<String>): String = buildString {
        appendLine("You are JARVIS, a concise, polite personal assistant running inside an Android app.")
        appendLine(language.promptInstruction)
        appendLine("You cannot directly operate the phone. Actions (opening links, drafting WhatsApp/SMS messages, calendar events, Daraz tasks) are done by the app's skills when the user phrases a command; every sensitive action needs the user's confirmation.")
        appendLine("Never claim that you already performed an action. Keep answers short unless asked for detail.")
        if (skillNames.isNotEmpty()) appendLine("Enabled skills: ${skillNames.joinToString(", ")}.")
        if (memories.isNotEmpty()) {
            appendLine("User-approved preferences to respect:")
            memories.forEach { appendLine("- $it") }
        }
    }.trim()
}

class AiClient(private val http: OkHttpClient) {
    suspend fun chat(endpoint: String, apiKey: String, payload: String): String = withContext(Dispatchers.IO) {
        if (!endpoint.startsWith("https://")) throw AiException("The endpoint must start with https://")
        val request = try {
            Request.Builder()
                .url(endpoint)
                .header("Authorization", "Bearer $apiKey")
                .post(payload.toRequestBody("application/json".toMediaType()))
                .build()
        } catch (e: IllegalArgumentException) {
            throw AiException("The endpoint URL is not valid.")
        }
        try {
            http.newCall(request).execute().use { resp ->
                val body = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) throw AiException(ChatPayload.describeHttpError(resp.code, body))
                ChatPayload.parseReply(body)
            }
        } catch (e: UnknownHostException) {
            throw AiException("No internet connection or unknown host.")
        } catch (e: SocketTimeoutException) {
            throw AiException("The request timed out. Check your connection and try again.")
        } catch (e: IOException) {
            throw AiException("Network error: ${e.message ?: "connection failed"}")
        }
    }
}
