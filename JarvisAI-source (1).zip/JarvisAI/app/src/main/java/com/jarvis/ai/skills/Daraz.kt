package com.jarvis.ai.skills

import com.jarvis.ai.data.SecureStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.io.IOException
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

class DarazException(message: String) : Exception(message)

data class DarazCredentials(val appKey: String, val appSecret: String, val accessToken: String) {
    val complete get() = appKey.isNotBlank() && appSecret.isNotBlank() && accessToken.isNotBlank()

    companion object {
        fun from(secure: SecureStore) = DarazCredentials(
            secure.get(SecureStore.DARAZ_APP_KEY),
            secure.get(SecureStore.DARAZ_APP_SECRET),
            secure.get(SecureStore.DARAZ_ACCESS_TOKEN),
        )
    }
}

data class OrdersSummary(val count: Int, val revenue: Double, val byStatus: Map<String, Int>) {
    fun describe(days: Int): String = buildString {
        appendLine("Daraz orders, last $days days: $count order(s), total value ${"%.2f".format(revenue)}.")
        byStatus.entries.sortedByDescending { it.value }.forEach { appendLine("• ${it.key}: ${it.value}") }
    }.trim()
}

/** Request signing for the Daraz Open Platform (HMAC-SHA256, as documented for the Lazada-family Open Platform). */
object DarazSigner {
    fun sign(apiPath: String, params: Map<String, String>, secret: String): String {
        val payload = apiPath + params.filterKeys { it != "sign" }.toSortedMap().entries.joinToString("") { it.key + it.value }
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(secret.toByteArray(Charsets.UTF_8), "HmacSHA256"))
        return mac.doFinal(payload.toByteArray(Charsets.UTF_8)).joinToString("") { "%02X".format(it) }
    }
}

object DarazParser {
    fun parseOrders(body: String): OrdersSummary {
        val root = try { JSONObject(body) } catch (e: Exception) { throw DarazException("Unexpected response from Daraz.") }
        val code = root.optString("code", "0")
        if (code != "0") throw DarazException("Daraz API error $code: ${root.optString("message", "unknown")}")
        val orders = root.optJSONObject("data")?.optJSONArray("orders")
            ?: return OrdersSummary(0, 0.0, emptyMap())
        var revenue = 0.0
        val byStatus = linkedMapOf<String, Int>()
        for (i in 0 until orders.length()) {
            val o = orders.getJSONObject(i)
            revenue += o.optString("price", "0").toDoubleOrNull() ?: 0.0
            val status = o.optJSONArray("statuses")?.optString(0)?.ifBlank { null } ?: "unknown"
            byStatus[status] = (byStatus[status] ?: 0) + 1
        }
        return OrdersSummary(orders.length(), revenue, byStatus)
    }
}

/**
 * Read-only client. UNVERIFIED against a live seller account: it needs a Daraz Open Platform
 * app (app key + secret) and a seller access token, which only you can obtain.
 */
class DarazApiClient(private val http: OkHttpClient) {
    private val base = "https://api.daraz.pk/rest"

    suspend fun fetchOrders(creds: DarazCredentials, days: Int): OrdersSummary = withContext(Dispatchers.IO) {
        if (!creds.complete) throw DarazException("Daraz credentials are incomplete.")
        val path = "/orders/get"
        val createdAfter = ZonedDateTime.now().minusDays(days.toLong()).truncatedTo(ChronoUnit.DAYS)
            .format(DateTimeFormatter.ISO_OFFSET_DATE_TIME)
        val params = linkedMapOf(
            "app_key" to creds.appKey,
            "timestamp" to System.currentTimeMillis().toString(),
            "sign_method" to "sha256",
            "access_token" to creds.accessToken,
            "created_after" to createdAfter,
        )
        val sign = DarazSigner.sign(path, params, creds.appSecret)
        val url = (base + path).toHttpUrl().newBuilder().apply {
            params.forEach { (k, v) -> addQueryParameter(k, v) }
            addQueryParameter("sign", sign)
        }.build()
        try {
            http.newCall(Request.Builder().url(url).get().build()).execute().use { resp ->
                val body = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) throw DarazException("Daraz returned HTTP ${resp.code}.")
                DarazParser.parseOrders(body)
            }
        } catch (e: IOException) {
            throw DarazException("Network error talking to Daraz: ${e.message}")
        }
    }
}

class DarazSkill(private val api: DarazApiClient) : Skill {
    override val id = "daraz"
    override val name = "Daraz Seller Center"
    override val description = "Opens Seller Center, summarises recent orders (needs Open Platform credentials) and drafts product descriptions with AI."
    override val requiredApps = listOf("Browser (Seller Center web) — or the Daraz Seller app")
    override val permissions = listOf(
        SkillPermission("Internet", "Calls the Daraz Open Platform API (read-only orders) when credentials are saved."),
        SkillPermission("Stored credentials", "App key, secret and token are kept encrypted on-device, set under Connected Apps."),
    )

    override suspend fun plan(input: String, ctx: SkillContext): SkillPlan {
        if (!input.has("daraz")) return SkillPlan.NotHandled
        val t = input.lowercase()
        return when {
            t.contains("description") || t.contains("listing") || t.contains("title") -> {
                val product = input.replace(Regex("(?i)\\b(?:daraz|description|listing|title|for|write|draft|prepare|a|the|product)\\b"), " ").replace(Regex("\\s+"), " ").trim()
                if (product.length < 3) SkillPlan.Reply("Which product? Say: \"Daraz description for stainless steel water bottle 750ml\".")
                else act(id, "draft_description", mapOf("product" to product), "Draft a Daraz product description for \"$product\"", sensitive = false, launchesUi = false)
            }
            t.contains("order") || t.contains("sales") || t.contains("summary") || t.contains("revenue") -> {
                if (!DarazCredentials.from(ctx.secure).complete) SkillPlan.Reply(
                    "Order data needs Daraz Open Platform credentials, which aren't set up. Add them under Connected Apps → Daraz.\n\nManual workflow: open Seller Center → Orders → filter by date and status → Export, then paste the figures here and I'll summarise them."
                ) else act(id, "orders_summary", mapOf("days" to "7"), "Fetch Daraz orders for the last 7 days (read-only)", sensitive = false, launchesUi = false)
            }
            t.contains("inventory") || t.contains("stock") -> SkillPlan.Reply(
                "Inventory changes aren't automated (changing stock is a write action I won't do unattended).\n\nManual workflow: Seller Center → Products → Manage Products → edit stock per SKU. Say \"Daraz seller center\" and I'll open it."
            )
            else -> act(id, "open_seller_center", emptyMap(), "Open Daraz Seller Center in the browser", sensitive = false, launchesUi = true)
        }
    }

    override suspend fun execute(action: PlannedAction, ctx: SkillContext): SkillOutcome = when (action.actionId) {
        "open_seller_center" -> IntentLauncher.launch(
            ctx.appContext,
            android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse("https://sellercenter.daraz.pk")),
            "Opened Seller Center in your browser.",
        )
        "orders_summary" -> try {
            SkillOutcome(true, api.fetchOrders(DarazCredentials.from(ctx.secure), action.params["days"]?.toIntOrNull() ?: 7).describe(7))
        } catch (e: DarazException) {
            SkillOutcome(false, e.message ?: "Daraz request failed.")
        }
        "draft_description" -> {
            val text = ctx.ask(
                "You write marketplace listings for Daraz Pakistan. Produce: a title (max 100 chars), 5 bullet highlights, and a 2-paragraph description. Do not invent specifications that the seller did not provide; mark unknowns as [fill in]. " + ctx.language.promptInstruction,
                "Product: ${action.params["product"].orEmpty()}",
            )
            SkillOutcome(true, "$text\n\n(Draft only — review before pasting into Seller Center.)")
        }
        else -> SkillOutcome(false, "Unknown Daraz action.")
    }
}
