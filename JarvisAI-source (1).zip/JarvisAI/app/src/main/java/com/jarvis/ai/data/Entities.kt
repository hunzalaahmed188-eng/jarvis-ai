package com.jarvis.ai.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "messages")
data class MessageEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    /** "user", "assistant" or "error". */
    val role: String,
    val content: String,
    val createdAt: Long = System.currentTimeMillis(),
)

@Entity(tableName = "memories")
data class MemoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val text: String,
    val createdAt: Long = System.currentTimeMillis(),
)

@Entity(tableName = "tasks")
data class TaskEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val skillId: String,
    val actionId: String,
    val paramsJson: String = "{}",
    val sensitive: Boolean = false,
    val launchesUi: Boolean = false,
    val status: String,
    val createdAt: Long = System.currentTimeMillis(),
    val scheduledAt: Long? = null,
    val attempts: Int = 0,
    val lastError: String? = null,
)

@Entity(tableName = "action_logs")
data class ActionLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val taskId: Long? = null,
    val message: String,
    val createdAt: Long = System.currentTimeMillis(),
)

/** Enabled / removed flag for any skill (built-in or custom). */
@Entity(tableName = "skill_state")
data class SkillStateEntity(
    @PrimaryKey val skillId: String,
    val enabled: Boolean = true,
    val removed: Boolean = false,
)

/** A user-created "prompt skill": a trigger phrase plus instructions sent to the AI model. */
@Entity(tableName = "custom_skills")
data class CustomSkillEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val description: String,
    val trigger: String,
    val instruction: String,
    val createdAt: Long = System.currentTimeMillis(),
)
